package DecimalToBinary;
import java.util.Scanner;
public class D_B_Main {
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		D_B_Class obj=new D_B_Class();
		System.out.println("Enter a number: ");
		int num=sc.nextInt();
		
		obj.create_Stack(10);
		while(num!=0) {
			
			int rem=num%2;
			if(rem==0) {
				obj.push(0);
			}else {
				obj.push(1);
			}
			num=num/2;
		}
		obj.print_Stack();
	}
}
