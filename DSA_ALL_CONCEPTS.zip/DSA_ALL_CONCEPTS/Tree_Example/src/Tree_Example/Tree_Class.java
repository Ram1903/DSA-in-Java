package Tree_Example;
import java.util.Scanner;
public class Tree_Class {
	int c=0;
	Node root;
	void create_Tree()
	{
	root=null;
	}
	void insert(Node r,Node n)  {
	if(root==null)
	root=n;
	else
	{
	if(n.data<r.data){
	if(r.left==null)
	r.left=n;
	else
	insert(r.left,n);
	}
	else {
	if(r.right==null)
	r.right=n;
	else
	insert(r.right,n);
	}
	}
	}
	void inorder(Node r) {
	if(r!=null)
	{
	inorder(r.left);//L
	System.out.print(r.data+",");//P 
	inorder(r.right);//L //R }
	}
	}
	void postOrder(Node r) {
		if(r!=null) {
			postOrder(r.left);//L
			postOrder(r.right);
			System.out.print(r.data+",");//P 
			
		}
		
	}
	void preorder(Node r) {
		if(r!=null) {
			System.out.print(r.data+",");
			preorder(r.left);
			preorder(r.right);
		}
	}
	
	int Leaf_Count(Node r) {
		if(r==null) {
			return 0;
		}
		if(r.left==null && r.right==null) {
			return 1;
		}
		return Leaf_Count(r.left)+Leaf_Count(r.right);
	}
	
	int Node_Count(Node r) {
		
		if(r==null) {
			return 0;
		}
		return 1 + Node_Count(r.left) + Node_Count(r.right);//1+ is for root
	}
	int Count_Without_Leaf(Node r) {
		if(r==null) {
			return 0;
		}
		if(r.left==null && r.right==null) {
			return 0;
		}
		return 1+Leaf_Count(r.left)+Leaf_Count(r.right);
	}
	Node search(Node r,int key) {
		if(r==null || r.data==key) {
			return r;
		}else {
			if(key<r.data) {
				return search(r.left,key);
			}
			if(key>r.data) {
				return search(r.right,key);
			}
		}
		return r;
	}
	public static void main(String args[])
	{
	Tree_Class obj=new Tree_Class();
	obj.create_Tree();
	int ch;
	Scanner sc=new Scanner(System.in);
	do{System.out.println("1.insert data\n2.inorder\n3.postorder\n4.preorder\n5.count leaf\n6.Total count\n7.count without leaf\n8.search\n0.exit");
	ch=sc.nextInt();
	switch(ch) {
	case 1:
		System.out.println("Enter number");
		int n=sc.nextInt();
		obj.insert(obj.root,new Node(n));
		System.out.println("Inserted");break;
		
	case 2:
		obj.inorder(obj.root);
		System.out.println();break;
	case 3:
		obj.postOrder(obj.root);
		System.out.println();break;
	case 4:
		obj.preorder(obj.root);
		System.out.println();break;
	case 5:
		System.out.println("Count of leaf is"+obj.Leaf_Count(obj.root));
		break;
	case 6:
		System.out.println("Total nodes are: "+obj.Node_Count(obj.root));
	case 7:
		System.out.println("Count Without leaf: "+obj.Count_Without_Leaf(obj.root));
	case 8:
		System.out.println("Search number: ");
		int s=sc.nextInt();
		Node res=obj.search(obj.root,s);
//		if(res==null) {
//			System.out.println("Not founr");
//		}else {
//			System.err.println("Found ");
//		}
	}
	}while(ch!=0);
//	System.out.println("\ncount of nodes "+obj.count_Leaf(obj.root));
//	Node res=obj.search(obj.root,5);
//	if(res==null) {
//		System.out.println("Not founr");
//	}else {
//		System.err.println("Found ");
//	}

	}
}
