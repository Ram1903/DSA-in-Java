package Bubble_sort;
import java.util.*;
public class BinarySearch {

	
		public static void main(String args[]) {
			Scanner sc=new Scanner(System.in);
			//int a[]= {11,44,33,22,88,55,99,66};
		    int a[]= {11,22,33,44,55,66,77,88,99};
//			System.out.println("Enter number to be searched");
//			int num=sc.nextInt();
			int key=44;
			int res=Binary_Search(a,0,a.length-1,key);
			if(res==-1) {
				System.out.println("Not found");
			}else {
				System.out.println(key+" Found at "+res);
			}
		}

		private static int Binary_Search(int[] a, int start,int end,int key) {
			// TODO Auto-generated method stub
			if(start<end) {
				int mid=(start+end)/2;
				if(a[mid]==key) {
					return mid;
				}else {
					if(key<a[mid]) {
						return Binary_Search(a,start,mid-1,key);
					}else {
						return Binary_Search(a,mid+1,end,key);
					}
				}
			}
			else {
				return -1;
			}
			
		}
	}


