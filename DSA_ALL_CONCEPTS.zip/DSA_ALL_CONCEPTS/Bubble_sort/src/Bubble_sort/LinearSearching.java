package Bubble_sort;
//linear search
public class LinearSearching {
	public static void main(String args[]) {
		int a[]= {22,11,33,55,77,66,44,99,88};
		int key=77;
		int res=Searching(a,key);
		if(res==-1) {
			System.out.println("Not found");
		}else {
			System.out.println(key+" Found at "+res);
		}
	}

	private static int LinearSearching(int[] a, int key) {
		// TODO Auto-generated method stub
		for(int i=0;i<a.length;i++) {
			if(key==a[i]) {
				return i;
			}
		}
		return -1;
	}
}
