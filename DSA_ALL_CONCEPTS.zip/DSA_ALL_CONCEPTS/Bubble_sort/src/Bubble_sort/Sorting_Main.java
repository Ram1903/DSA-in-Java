package Bubble_sort;

public class Sorting_Main
{
    static void print_array(int a[])
    {
        System.out.println("\narray has:");
        for(int i=0;i<a.length;i++)
        {
            System.out.print(a[i]+",");
        }
    }
    public static void main(String args[])
    {
        int a[]={33,11,77,55,66,22,88,99,44};
//        print_array(a);
//        Sorting_class.sort(a);
//        print_array(a);
//        Quick.sort(a, 0, 8);
//        print_array(a);
//        MergeSort.merge_Sort(a,0,a.length-1);
//        print_array(a);
        Heap.heap(a);
        System.out.println("\nHeap sort");
        print_array(a);
    }

}