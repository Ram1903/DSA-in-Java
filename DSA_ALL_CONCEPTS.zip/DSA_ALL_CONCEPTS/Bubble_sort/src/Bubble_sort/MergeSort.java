package Bubble_sort;

public class MergeSort {
	static void merge_Sort(int a[],int start, int end) {
		if(start<end) {
			int mid=(start+end)/2;
			merge_Sort(a,start,mid);
			merge_Sort(a,mid+1,end);
			merger(a,start,mid,end);
		}
	}

	private static void merger(int[] a, int start, int mid, int end) {
		int i=start;
		int j=mid+1;
		int temp[]=new int[a.length];
		int tindex=start;
		while(i<=mid && j<=end) {
			if(a[i]<a[j]) {
				temp[tindex++]=a[i++];
			
			}else {
				temp[tindex++]=a[j++];
			}
		}
		while(i<=mid) {
			temp[tindex++]=a[i++];
			
		}
		while(j<=end) {
			temp[tindex++]=a[j++];
		}
		for(i=start;i<=end;i++) {
			a[i]=temp[i];
		}
	}
}
