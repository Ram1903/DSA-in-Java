package Bubble_sort;

public class Quick
{
    static void sort(int a[],int start,int end)
    {
        int i,j,pivot,temp;
        i=start;
        j=end;
        pivot=end;
        while(i<j)
        {
            while(a[i]<a[pivot])
                i++;
            while(a[j]>a[pivot])
                j--;
            if(i<j)
            {
                temp=a[j];
                a[j]=a[i];
                a[i]=temp;
            }
        }//while
        if(i<end)
            sort(a,i+1,end);
        if(j>start)
            sort(a,start,j-1);
    }


}
