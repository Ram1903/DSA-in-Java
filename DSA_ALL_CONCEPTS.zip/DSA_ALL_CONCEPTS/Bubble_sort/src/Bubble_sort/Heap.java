package Bubble_sort;

public class Heap {
	static void heap(int a[]) {
		int i,j,current;
		for(i=a.length-1;i>0;i--) {
			for(j=0;j<=i;j++) {
				current=j;
				boolean done=true;
				while(current>0 && current/2>=0 ) {//extreem condition
					if(a[current/2]<a[current]) {//parent<child then swap
						int temp=a[current];
						a[current]=a[current/2];
						a[current/2]=temp;
					}else {
						done=false;
					}
					current=current/2;
				}
				
			}//for j loop
			int temp=a[0];
			a[0]=a[i];
			a[i]=temp;
		}//for i
	}//for static
}
