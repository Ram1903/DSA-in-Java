
package Bubble_sort;

public class Sorting_class
{
    static void sort(int a[])
    {
        int i,j,temp;
        //passes n-1
        for(i=a.length-1;i>0;i--)
        {
            int min=a[0];
            boolean flag=false;
            //sort
            for(j=0;j<i;j++)
            {
                if(a[j]>a[j+1])
                {
                    flag=true;
                    if(a[i]<min) {
                    	min=a[i];
                    }
                    temp=a[j];
                    a[j]=a[j+1];
                    a[j+1]=temp;
                }
            }
            if(flag==false)//swap no needed means sorted
                break;
        }

    }
}