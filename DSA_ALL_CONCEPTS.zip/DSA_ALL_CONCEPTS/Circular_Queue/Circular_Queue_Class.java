package Circular_Queue;


public class Circular_Queue_Class {
	int Queue[],front,rear,MaxSize,count;

	void create_Queue(int size)
	{
	MaxSize=size;
	Queue=new int[MaxSize];
	front=0;
	rear=-1;
	}
	void enque(int e) //entry on queue
	{count++;
	rear=(rear+1)%MaxSize;
	Queue[rear]=e;
	}
	//stack[++rear]=e; }
	boolean is_Full()
	{
	if(count==MaxSize)
	return true;
	else
	return false;
	}
	//return rear==Maxsize-1 }

	int Dequeue(){//removes and return {
		//Deletion from queue
		count--;
	int temp=Queue[front];
	front=(front+1)%MaxSize;
	return temp;
	}
	
	boolean is_Empty()
	{
	if(count==0) {
	return true;
	}
	else {
	return false;
	}
	}
	
	void print_queue()
	{
	int c,i;
	i=front;
	c=0;
	while(c<count) {
	System.out.print(Queue[i]+"---");
	i=(i+1)%MaxSize;
	c++;
	}

}

}