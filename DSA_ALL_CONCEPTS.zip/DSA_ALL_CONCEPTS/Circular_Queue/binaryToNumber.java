package Circular_Queue;
import java.util.Scanner;
public class binaryToNumber {
	public static void main(String args[]) {
		 Circular_Queue_Class obj = new Circular_Queue_Class();
		 Scanner sc=new Scanner(System.in);
	        System.out.println("Enter size of Queue:");
	        int choice, e;
	        int sum=0;
	        int size = sc.nextInt();
	        int n=size;
	        obj.create_Queue(size);
	        System.out.println("Enter binay numbers: ");
	        for(int i=0;i<size;i++) {
	        	e=sc.nextInt();
	        	obj.enque(e);
	        }
	       
	        while(!obj.is_Empty()) {
	        	sum+=(obj.Dequeue()*Math.pow(2, n-1));
	        	n--;
	        }
	        System.out.println(sum);
	}
}
