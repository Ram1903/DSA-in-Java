package Assign;

public class LinkedListClass {

}
