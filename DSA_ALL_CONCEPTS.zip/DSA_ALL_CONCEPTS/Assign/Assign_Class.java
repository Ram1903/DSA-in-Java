package Assign;

import java.util.Scanner;

public class Assign_Class {
    char queue[];
    int rear, front, MaxSize, count;
    Scanner sc = new Scanner(System.in);

    void create_Queue(int size) {
        MaxSize = size;
        queue = new char[MaxSize];
        rear = -1;
        front = 0;
        count = 0;
    }

    void enqueue(char e) {
        if (is_Full()) {
            System.out.println("Queue is full.");
            return;
        }

        System.out.println("1.left 2.right");
        int ch = sc.nextInt();

        switch (ch) {
            case 1:
                front = (front - 1 + MaxSize) % MaxSize;
                queue[front] = e;
                break;

            case 2:
                rear = (rear + 1) % MaxSize;
                queue[rear] = e;
                break;

            default:
                System.out.println("Invalid choice.");
                return;
        }
        count++;
    }

    char dequeue() {
        if (is_Empty()) {
            System.out.println("Queue is empty.");
            return '\0';
        }

        System.out.println("1. Remove left 2. Remove right");
        int ch = sc.nextInt();
        char temp = 0;

        switch (ch) {
            case 1:
                temp = queue[front];
                front = (front + 1) % MaxSize;
                break;

            case 2:
                temp = queue[rear];
                rear = (rear - 1 + MaxSize) % MaxSize;
                break;

            default:
                System.out.println("Invalid choice.");
              
        }
        count--;
        return temp;
    }

    void print_Queue() {
        if (is_Empty()) {
            System.out.println("Queue is empty.");
            return;
        }

        System.out.println("1.left to right 2.right to left");
        int ch = sc.nextInt();

        switch (ch) {
            case 1:
                int i = front, c = 0;
                while (c < count) {
                    System.out.print(queue[i] + "__");
                    i = (i + 1) % MaxSize;
                    c++;
                }
                break;

            case 2:
                i = rear;
                c = 0;
                while (c < count) {
                    System.out.print(queue[i] + "__");
                    i = (i - 1 + MaxSize) % MaxSize;
                    c++;
                }
                break;

            default:
                System.out.println("Invalid choice.");
        }
        System.out.println();
    }

    boolean is_Empty()
	{
	  if(front>rear) {
	     return true;
	  }
	  else {
	     return false;
	  }
	}

    boolean is_Full()
	{
	if(rear==MaxSize-1)
	return true;
	else
	return false;
	}
}
