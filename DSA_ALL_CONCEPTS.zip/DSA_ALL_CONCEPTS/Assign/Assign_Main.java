package Assign;

import java.util.Scanner;

public class Assign_Main {
    public static void main(String args[]) {
        Assign_Class obj = new Assign_Class();
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter size of queue: ");
        int size = sc.nextInt();
        obj.create_Queue(size);

        int choice;
        System.out.println();
        do {
            System.out.println("\nQueue Menu");
            System.out.println("-----------");
            System.out.println("1. Enqueue");
            System.out.println("2. Dequeue");
            System.out.println("3. Display");
            System.out.println("0. Exit");
            System.out.print("Choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.println("Enter Character");
                    char n = sc.next().charAt(0);
                    obj.enqueue(n);
                    System.out.println(n + " added to the queue");
                    break;

                case 2:
                    char r = obj.dequeue();
                        System.out.println(r + " removed from the queue");
                  
                    break;

                case 3:
                    obj.print_Queue();
                    break;

                default:
                    System.out.println("Invalid choice");
                    break;
            }
        } while (choice != 0);
        
        sc.close();
    }
}
