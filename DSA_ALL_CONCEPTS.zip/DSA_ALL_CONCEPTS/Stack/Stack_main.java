/*This Java program demonstrates a simple Stack implementation using an interactive, menu-driven approach. The Stack_main class allows users to perform essential stack operations: Push, Pop, Peek, and Print. The program prompts the user to input the stack size and then displays a menu to select operations.

Push: Adds an element to the top if space is available.
Pop: Removes and displays the top element if the stack isn’t empty.
Peek: Shows the current top element without removal.
Print: Displays all elements in the stack.
The program will exit when the user selects the Exit option.*/
package Stack;
import java.util.Scanner;
public class Stack_main
{
    public static void main(String args[]) {
        Scanner in = new Scanner(System.in);
        Stack_class obj = new Stack_class();
        System.out.println("Enter size of stack:");
        int choice, e;
        int size = in.nextInt();
        obj.create_Stack(size);
        //menu driven code for stack
        do{
            System.out.println("\nStack Menu");
            System.out.println("-----------");
            System.out.println("1.Push");
            System.out.println("2.Pop");
            System.out.println("3.Peek");
            System.out.println("4.Print");
            System.out.println("0.Exit");
            System.out.print("Choice:");
            choice = in.nextInt();
            switch (choice) {
                case 1:
                    if (obj.is_Full() != true)//if not full
                    {
                        System.out.print("Enter element:");
                        e = in.nextInt();
                        obj.push(e);
                        System.out.print("Entered " + e + " on stack");
                    } else
                        System.out.print("Stack Full");
                    break;
                case 2:
                    if (obj.is_Empty() != true)//if not empty
                        System.out.print("Element poped:" + obj.pop());
                    else
                        System.out.print("Stack Empty");
                    break;
                case 3:
                    if (obj.is_Empty() != true)//if not empty
                        System.out.print("Element @ peek:" + obj.peek());
                    else
                        System.out.print("Stack Empty");
                    break;
                case 4:
                    if (obj.is_Empty() != true)//if not empty
                    {
                        System.out.print("Element in stack are:");
                        obj.print_Stack();
                    } else
                        System.out.print("Stack Empty");
                    break;
                case 0:
                    System.out.print("Exiting code");
                    break;
                default:
                    System.out.print("Wrong option selected...");
                    break;
            }
     }while(choice!=0);
    }
}

