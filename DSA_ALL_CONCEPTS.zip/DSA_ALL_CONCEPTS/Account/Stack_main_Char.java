package Account;
import java.util.Scanner;
public class Stack_main_Char {
	static boolean check(String test) {
		Stack_Class_Char obj=new Stack_Class_Char();
		obj.create_Stack(test.length());
		
		
		for(int i=0;i<test.length();i++) {
			
			char c=test.charAt(i);
			
			if(c=='{') {
				obj.push(c);
 			}else if(c=='}') {
 				if(!obj.is_Empty()) {
 					char g=obj.pop();
 				}else {
 					return false;
 				}
 			}
		}
		return obj.is_Empty();
	}
public static void main(String args[]) {
	String line;
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter pattern to check: ");
	line=sc.next();
	
	System.out.println(line+" is balance: "+check(line));
	
  }
}
