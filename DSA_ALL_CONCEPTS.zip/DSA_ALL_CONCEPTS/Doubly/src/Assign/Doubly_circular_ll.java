package Assign;

public class Doubly_circular_ll {
    Dnode root, last;

    void Create_List() {
        root = last = null;
    }

    void insert_left(int data) {
        Dnode n = new Dnode(data);
        if (root == null) {
            root = n;
            root.left = root;
            root.right = root;
            last = root;
        } else {
            n.right = root;
            n.left = last;
            root.left = n;
            last.right = n;
            root = n;
        }
    }

    void insert_right(int data) {
        Dnode n = new Dnode(data);
        if (root == null) {
            root = n;
            root.left = root;
            root.right = root;
            last = root;
        } else {
            last.right = n;
            n.left = last;
            n.right = root;
            root.left = n;
            last = n;
        }
    }

    void Delete_right() {
        if (root == null) {
            System.out.println("List is empty");
        } else {
            Dnode temp = last;
            if (root == last) {
                root = null;
            } else {
                last = last.left;
                last.right = root;
                root.left = last;
            }
            System.out.println(temp.data + " removed");
        }
    }

    void Delete_left() {
        if (root == null) {
            System.out.println("List is empty");
        } else {
            if (root == last) {
                root = null;
            } else {
                root = root.right;
                root.left = last;
                last.right = root;
            }
        }
    }

    void print() {
        if (root == null) {
            System.out.println("Empty");
        } else {
            Dnode t = root;
            do {
                System.out.print(t.data + "--");
                t = t.right;
            } while (t != root);
        }
        System.out.println(" ");
    }

    void print_rev() {
        if (root == null) {
            System.out.println("Empty");
        } else {
            Dnode t = last;
            do {
                System.out.print(t.data + "--");
                t = t.left;
            } while (t != last);
        }
        System.out.println();
    }
}
