package CircularDoubly;

public class DNode {
	int data;
	DNode left,right;
	DNode(int data){
		this.data=data;
		left=right=null;
	}
}
