package Doubly;


public class DClass {
	DNode root;
    void create_List()
    {
        root=null;//making root null at start
    }

    void insert_Left(int data)
    {
        DNode n=new DNode(data);
        if(root==null)
            root=n;
        else
        {
            n.right=root;//1
            root.left=n;//2
            root=n;//3
        }
        System.out.println(data+" inserted in list");
    }
    void delete_Left()
    {
        if (root == null)
            System.out.println("Empty List:");
        else {
            DNode t = root;//1
            if(root.right==null)//single node
                root=null;
            else {
                root = root.right;//2
                root.left = null;//3
            }
            System.out.println(t.data + " Deleted from list");//3
        }
    }
    void insert_Right(int data)
    {
        DNode n=new DNode(data);
        if(root==null)
            root=n;
        else
        {
            DNode t=root;//1
            while(t.right!=null)//2
                t=t.right;
            t.right=n;//3
            n.left=t;//4
        }
        System.out.println(data+" inserted in list");
    }
    void delete_Right()
    {
        if (root == null)
            System.out.println("Empty List:");
        else
        {
            DNode t = root;//1
            if(root.right==null)//single node
                root=null;
            else
            {
                while(t.right!=null)
                { t=t.right;}//next
                DNode t2=t.left;//go back
                t2.right=null;//3
            }
            System.out.println(t.data + " Deleted from list");//4
        }
    }

    void print_list()
    {
        if (root == null)
            System.out.println("Empty List:");
        else
        {
            DNode t=root;
            while(t!=null)
            {
                System.out.print("<-|"+t.data +"|->");
                t=t.right;
            }
        }
    }
    void print_list_rev()//last to first
    {
        if (root == null)
            System.out.println("Empty List:");
        else
        {
            DNode t=root;//1
            while(t.right!=null)//2
                t=t.right;
            while(t!=null)//3
            {
                System.out.print("<-|"+t.data +"|->");
                t=t.left;
            }
        }
    }
}
