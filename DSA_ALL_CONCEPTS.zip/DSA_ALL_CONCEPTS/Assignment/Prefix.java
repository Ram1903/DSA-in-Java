package Assignment;
import java.util.Scanner;
public class Prefix {
	public static int Precedence(char c)
	{
		System.out.println("priority");
		if(c == '('||c==')') return 0;
		else if(c == '+' || c=='-') return 1;
		else if(c == '*' || c=='/' || c=='%') return 2;
		else if(c=='^') return 3;
		
		return -1;
		
	}
	public static void main(String args[]) {
		Assign_Class obj=new Assign_Class();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter equation");
		String inp=sc.next();
		String prefix="";
		obj.create_Stack(inp.length());
		for(int i=inp.length()-1;i>=0;i--) {
			char c=inp.charAt(i);
			switch(c) {
			case ')':
				obj.push(c);
				break;
			case '(':
				while(obj.peek()!=')') {
					prefix += obj.pop();
				}
				obj.pop();
				
			case '^':case '+': case '-': case '*': case '/': case '%':
				 while (!obj.is_Empty() && Precedence(c) < Precedence(obj.peek())) {
                     prefix += obj.pop();
                 }
                 obj.push(c);
                 break;
             default:
                 prefix += c;
												
			}
		}
		while (!obj.is_Empty()) {
            prefix += obj.pop();
        }

        StringBuilder fa = new StringBuilder(prefix);
        System.out.println("ans: " + fa.reverse().toString());
        sc.close();
		
	}
}
