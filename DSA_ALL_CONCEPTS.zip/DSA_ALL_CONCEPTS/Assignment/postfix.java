package Assignment;
import java.util.Scanner;
public class postfix {
	public static int Precedence(char c)
	{
		System.out.println("Precedence priority");
		if(c == '('||c==')') return 0;
		else if(c == '+' || c=='-') return 1;
		else if(c == '*' || c=='/' || c=='%') return 2;
		else if(c=='^') return 3;
		
		return -1;
		
	}
     public static void main(String args[]) {
    	 Assign_Class obj=new Assign_Class();
    	 Scanner sc=new Scanner(System.in);
    	 String postfix="";
    	 
    	 String s=sc.next();   //input string liye
    	 int l=s.length();
    	 
    	 obj.create_Stack(l);  //stack create
    	 
    	 
    	 for(int i=0;i<l;i++) {
    		 char c=s.charAt(i);
    		 switch(c) {
    		 case '(':
    			 obj.push(c);
    			 break;
    			 
    		 case ')':
    			 while(obj.pop()!='(') {
    				 //if(obj.pop()!='(')
    				 postfix=postfix+obj.pop();
    		 }
    			 obj.pop();
    		 
    		 
    	 case '^':case '+': case '-': case '*': case '/': case '%':
    		 while(!obj.is_Empty() && Precedence(c) < Precedence(obj.peek())) {
    			 postfix=postfix+obj.pop();
    		 }
    		 obj.push(c);
    		 break;
    	default:postfix+=c;
    	
    	
    	 
    	 }
    	 
     }
    	 while (!obj.is_Empty()) {
             postfix += obj.pop();
         }

         System.out.println("ans: " + postfix);
         sc.close();
}
}