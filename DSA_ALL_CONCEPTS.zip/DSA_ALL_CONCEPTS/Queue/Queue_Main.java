package Queue;

import java.util.Scanner;

public class Queue_Main {

    public static void main(String args[]) {
        Scanner in = new Scanner(System.in);
        Queue_Class obj = new Queue_Class();
        System.out.println("Enter size of Queue:");
        int choice, e;
        int size = in.nextInt();
        obj.create_Queue(size);
        //menu driven code for stack
        do{
            System.out.println("\nQueue Menu");
            System.out.println("-----------");
            System.out.println("1.enque");
            System.out.println("2.dequeue");
            System.out.println("3.display");
            System.out.println("0.Exit");
            System.out.print("Choice:");
            choice = in.nextInt();
            switch (choice) {
                case 1:
                    if (obj.is_Full() != true)//if not full
                    {
                        System.out.print("Enter element:");
                        e = in.nextInt();
                        obj.enque(e);
                        System.out.print("Entered " + e + " on queue");
                    } else
                        System.out.print("Queue Full");
                    break;
                case 2:
                    if (obj.is_Empty() != true)//if not empty
                        System.out.print("Element deque:" + obj.Dequeue());
                    else
                        System.out.print("queue Empty");
                    break;
                
                case 3:
                    if (obj.is_Empty() != true)//if not empty
                    {
                        System.out.print("Element in queue are:");
                        obj.print_queue();;
                    } else
                        System.out.print("queue Empty");
                    break;
                case 0:
                    System.out.print("Exiting code");
                    break;
                default:
                    System.out.print("Wrong option selected...");
                    break;
            }
     }while(choice!=0);
    }
}
