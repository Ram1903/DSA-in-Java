package Queue;

public class Queue_Class {
	int Queue[],front,rear,MaxSize;

	void create_Queue(int size)
	{
	MaxSize=size;
	Queue=new int[MaxSize];
	front=0;
	rear=-1;
	}
	void enque(int e) //entry on queue
	{
	rear++;
	Queue[rear]=e;
	}
	//stack[++rear]=e; }
	boolean is_Full()
	{
	if(rear==MaxSize-1)
	return true;
	else
	return false;
	}
	//return rear==Maxsize-1 }

	int Dequeue(){//removes and return {
		//Deletion from queue
	int temp=Queue[front];
	front++;
	return temp;
	}
	
	boolean is_Empty()
	{
	if(front>rear) {
	return true;
	}
	else {
	return false;
	}
	}
	
	void print_queue()
	{
	for(int i=front;i<=rear;i++)
	System.out.println(Queue[i]);
	}

}
