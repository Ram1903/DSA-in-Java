package stackQueueUsingLinear;

public class Class {

	 Node front, rear;//container-ship

	    void create_Queue() {
	        front = rear = null;
	    }

	    void Enqueue(int data) {
	        Node n = new Node(data);
	        if (rear == null) {
	            front = rear = n;
	        } else {
	            rear.next = n;
	            rear = n;
	        }
	        System.out.println(data + " inserted in Queue");
	    }

	    void Dequeue() {
	        if (front == null)
	            System.out.println("Empty Queue:");
	        else {
	            Node t = front;//1
	            if (front == rear)//single node
	                front = rear = null;//removed
	            else
	                front = front.next;//2
	            System.out.println(t.data + " Deleted from queue");//3
	        }
	    }

	    void print_queue() {
	        if (front == null)
	            System.out.println("Empty Queue:");
	        else {
	            Node t = front;
	            while (t != null) {
	                System.out.print("|" + t.data + "|-");
	                t = t.next;
	            }
	        }
	    }
	    }

