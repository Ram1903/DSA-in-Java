package stackQueueUsingLinear;
import java.util.Scanner;
public class C_Main
{
    public static void main(String args[]) {
        Scanner in = new Scanner(System.in);
        Class obj=new Class();
        int choice, e;
        obj.create_Queue();
        //menu driven code for stack
        do{
            System.out.println("\nQueue Menu");
            System.out.println("-----------");
            System.out.println("1.Enqueue");
            System.out.println("2.Dequeue");
            System.out.println("3.Print");
            System.out.println("0.Exit");
            System.out.print("Choice:");
            choice = in.nextInt();
            switch (choice) {
                case 1:
                        System.out.print("Enter element:");
                        e = in.nextInt();
                        obj.Enqueue(e);
                        break;
                case 2:
                        obj.Dequeue();
                        break;
                case 3:
                        System.out.print("Element in queue are:");
                        obj.print_queue();
                         break;
                case 0:
                    System.out.print("Exiting code");
                    break;
                default:
                    System.out.print("Wrong option selected...");
                    break;
            }
        }while(choice!=0);
    }
}
