package reverse;


public class Linkedlist {

	StackClass obj=new StackClass();
	 Node front, rear;int count=0;
	 void create_Queue() {
	        front = rear = null;
	    }

	    void Enqueue(int data) {
	    	count++;
	        Node n = new Node(data);
	        if (rear == null) {
	            front = rear = n;
	        } else {
	            rear.next = n;
	            rear = n;
	        }
	        System.out.println(data + " inserted in Queue");
	    }

	    void Dequeue() {
	    	count--;
	        if (front == null)
	            System.out.println("Empty Queue:");
	        else {
	            Node t = front;//1
	            if (front == rear)//single node
	                front = rear = null;//removed
	            else
	                front = front.next;//2
	            System.out.println(t.data + " Deleted from queue");//3
	        }
	    }

	    void print_queue() {
	    	obj.create_Stack(count);
	        if (front == null)
	            System.out.println("Empty Queue:");
	        else {
	            Node t = front;
	            int i=0;
	            while (t != null) {
	            	obj.push(t.data);
	            	System.out.print(t.data+"----");
	                t = t.next;
	            }
	        }
	        System.out.println("\nReversed");
	        for(int i=0;i<count;i++) {
	        	System.out.print(obj.pop()+"---");;
	        }
	    }
}
