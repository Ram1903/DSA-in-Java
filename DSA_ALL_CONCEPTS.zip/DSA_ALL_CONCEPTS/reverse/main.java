package reverse;

import java.util.Scanner;

public class main {
	public static void main(String args[]) {
		 Scanner sc=new Scanner(System.in);
		   Linkedlist obj=new Linkedlist();
		   int choice;
		   do{
	           System.out.println("\n Menu");
	           System.out.println("-----------");
	           System.out.println("1.enque");
	           
	           System.out.println("2.deque");
	           System.out.println("3.print");
	          
	         
	           System.out.println("0.Exit");
	           System.out.print("Choice:");
	           choice = sc.nextInt();
	           switch (choice) {
	           case 1:
	        	   System.out.println("Enter element");
	        	   int e=sc.nextInt();
	        	   obj.Enqueue(e);
	        	   break;
	           
	           case 2:
	               obj.Dequeue();
	               System.out.println("Deleted");
	               break;
	           
	           case 3:
	        	   System.out.println("Enter element");
	        	    obj.print_queue();
	        	   break;
	        	   
	        
	           
	           default:
	        	   System.out.println("Invalid input:");
	           }
		
		   }while(choice!=0);
	}
}
