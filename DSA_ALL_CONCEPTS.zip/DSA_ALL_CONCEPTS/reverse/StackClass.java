package reverse;

public class StackClass {


    //menu driven code for stack
    //1.push 2.pop 3.peek 4.print stack

   
int stack[],tos,MaxSize;

void create_Stack(int size)
{
MaxSize=size;
stack=new int[MaxSize];
tos=-1;
}
void push(int e)
{
tos++;
stack[tos]=e;
}
//stack[++tos]=e; }
boolean is_Full()
{
if(tos==MaxSize-1)
return true;
else
return false;
}
//return tos==Maxsize-1 }

int pop(){//removes and return {
int temp=stack[tos];
tos--;
return temp;
}
int peek(){//only returns {
return stack[tos];
}
boolean is_Empty()
{
if(tos==-1)
return true;
else
return false;
}
//return tos==-1 }
void print_Stack()
{
for(int i=tos;i>-1;i--)
System.out.println(stack[i]);
}


}
