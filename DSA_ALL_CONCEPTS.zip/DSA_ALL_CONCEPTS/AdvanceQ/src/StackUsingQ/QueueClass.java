package StackUsingQ;

import java.util.Scanner;

public class QueueClass {
	int queue[],MaxSize,front,rear;
	void resetQueue() {
		
	}
    void createQueue(int size)
    {
        rear=-1;
        front=0;
        MaxSize=size;
        queue=new int[MaxSize];

    }
    void enqueue(int element)
    {
        rear++;
        queue[rear]=element;
    }
    boolean is_Full()
    {
        if(rear==MaxSize-1)
            return true;
        else
            return false;
    }
    int dequeue()
    {
        int temp=queue[front];
        front++;
        return(temp);
    }
    boolean is_Empty()
    {
        if(front>rear)
            return true;
        else
            return false;
    }


    void print_queue()
    {
        for(int i=front;i<=rear;i++)
            System.out.print(queue[i]+"--");
    }

    public static void main(String args[]) {
        int ch;
        Scanner in = new Scanner(System.in);
        QueueClass Q1 = new QueueClass();
        QueueClass QT = new QueueClass();

        System.out.println("Enter size of stack:");
        int size = in.nextInt();
        Q1.createQueue(size);//user given size :stack
        QT.createQueue(size);//user given size :stack


        do {
            System.out.println("1.Push\n2.Pop\n3.Peek\n4.Print\n0.Exit\n:");
            ch = in.nextInt();
            switch (ch) {
                case 1:
                    if (!Q1.is_Full())//if not full then take data
                    {
                        System.out.println("Enter data to push:");
                        int e = in.nextInt();
                        Q1.enqueue(e);//push
                        System.out.println("Data pushed to stack");
                    } else {
                        System.out.println("Stack Full");
                    }
                    break;
                case 2:
                    if (!Q1.is_Empty())//if not Empty then dequeue
                    {
                    	QT.resetQueue();
                        while (Q1.front != Q1.rear)
                            QT.enqueue(Q1.dequeue());

                        int e = Q1.dequeue();
                        System.out.println("Data Poped:" + e);

                        while (!QT.is_Empty())
                            Q1.enqueue(QT.dequeue());
                    } else {
                        System.out.println("Stack Empty");
                    }
                    break;
                case 3:
                    if (!Q1.is_Empty())//if not Empty then print
                    {
                        System.out.println("Data in Stack");
                        Q1.print_queue();
                    } else {
                        System.out.println("Stack Empty");
                    }
                    break;
                case 0:
                    System.out.println("Exiting.....");
                    break;
                default:
                    System.out.println("Wrong option selected");
                    break;
            }
        } while (ch != 0);
    }
}
