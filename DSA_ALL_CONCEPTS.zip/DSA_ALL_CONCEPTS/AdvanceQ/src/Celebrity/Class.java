package Celebrity;

public class Class {

}
