/**
 * 
 */
/**
 * 
 */
module AdvanceQ {
}