package ImplementArrayUsingTree;

public class Class {
	 int tree[];
	    void create_tree(int size)
	    {
	        tree=new int[2*size];
	        for(int i=0;i<tree.length;i++)
	            tree[i]=-1;
	    }
	    void insert(int element)
	    {
	        if(tree[0]==-1)//if root is null then element is root
	            tree[0]=element;
	        else
	        {
	          int i=0;
	          while(true)
	          {
	              if(element<tree[i])//element is lesser than root go to left
	              {
	                  if (tree[2 * i + 1] == -1)//is left free then assign else go to left and check
	                  {
	                      tree[2 * i + 1] = element;
	                      break;
	                  }
	                  else
	                      i = 2 * i + 1;

	              }
	               else//right
	                  {
	                      if(tree[2*i+2]==-1)//is left free then assign else go to left and check
	                      {
	                          tree[2 * i + 2] = element;
	                          break;
	                      }
	                      else
	                          i = 2 * i + 2;
	                  }
	              }

	          }
	        }
	        void print_Tree()
	        {
	            for(int i=0;i<tree.length;i++)
	                System.out.print(tree[i]+" , ");
	    }
	    public static void main(String args[])
	    {
	        Class obj=new Class();
	        obj.create_tree(7);
	        obj.insert(10);
	        obj.insert(5);
	        obj.insert(1);
	        obj.insert(8);
	        obj.insert(20);
	        obj.insert(15);
	        obj.insert(30);
	        obj.print_Tree();
	    }}

