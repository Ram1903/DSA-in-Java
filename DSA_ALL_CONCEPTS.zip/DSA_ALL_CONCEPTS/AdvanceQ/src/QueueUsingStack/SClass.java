package QueueUsingStack;
//inmplement queue using stack
//implement fifo structure using lifo
public class SClass {

}
