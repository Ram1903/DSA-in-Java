package ReverseLine;
import java.util.Scanner;

public class RLClass {
	String stack[];
	int tos, MaxSize;

	void create_Stack(int size) {
		MaxSize = size;
		stack = new String[MaxSize];
		tos = -1;
	}
	void push(String word) {
		tos++;
		stack[tos] = word;
	}
	boolean is_Full() {
		return tos == MaxSize - 1;
	}
	String pop() {
		String temp = stack[tos];
		tos--;
		return temp;
	}
	String peek() {
		return stack[tos];
	}
	boolean is_Empty() {
		return tos == -1;
	}
	void print_Stack() {
		for (int i = tos; i > -1; i--)
			System.out.println(stack[i]);
	}

	
	
	
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		RLClass obj = new RLClass();
		String nstr = "";
		System.out.println("Enter string");
		String str = sc.nextLine();
		String[] words = str.split(" ");
		obj.create_Stack(str.length());
		
		for (String word : words) {
			obj.push(word);
	}
		while (!obj.is_Empty()) {
			nstr = nstr +  obj.pop()+" ";
	}		
		System.out.println(nstr.trim());
		sc.close();
	}}
