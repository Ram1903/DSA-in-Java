package SlidingWindow;
import java.util.Scanner;
//implement sliding window on queue and print min and max on every slide, 
//user would give side of window
public class classm {
	Scanner sc=new Scanner(System.in);
		int Queue[],front,rear,MaxSize;
		int t=front;
		void create_Queue(int size)
		{
		MaxSize=size;
		Queue=new int[MaxSize];
		front=0;
		rear=-1;
		}
		void enque(int e) //entry on queue
		{
		rear++;
		Queue[rear]=e;
		}
		//stack[++rear]=e; }
		boolean is_Full()
		{
		if(rear==MaxSize-1)
		return true;
		else
		return false;
		}
		//return rear==Maxsize-1 }

		int Dequeue(){//removes and return {
			//Deletion from queue
		int temp=Queue[front];
		front++;
		return temp;
		}
		
		boolean is_Empty()
		{
		if(front>rear) {
		return true;
		}
		else {
		return false;
		}
		}
		
		void window(int s) {
			do {
			int cur=t;
			int min=Queue[cur];
			int max=Queue[cur];
			while(cur<(s-1)) {
				cur++;
				if(min>Queue[cur]) {
					min=Queue[cur];
				}
				if(max<Queue[cur]) {
					max=Queue[cur];
				}
			}
			System.out.print("min: "+min+" max: "+max);
			System.out.println();
			System.out.println("Enter next Starting index");
			int nsw=sc.nextInt();
			System.out.println("Enter window size");
			 int ws=sc.nextInt();
		        while(ws>MaxSize) {
		        	System.out.println("Window size cant be greater than queue size");
		        	ws=sc.nextInt();
		    }
		     
			t=nsw;
			s=t+ws;
			}while(s!=MaxSize);
		}
		
		void print_queue()
		{
		for(int i=front;i<=rear;i++)
		System.out.println(Queue[i]);
		}
		
		    public static void main(String args[]) {
		        Scanner in = new Scanner(System.in);
		        classm obj = new classm();
		        System.out.println("Enter size of Queue:");
		        int choice, e;
		        int size = in.nextInt();
		        obj.create_Queue(size);
		        //menu driven code for stack
		        do{
		            System.out.println("\nQueue Menu");
		            System.out.println("-----------");
		            System.out.println("1.enque");
		            System.out.println("2.dequeue");
		            System.out.println("3.display");
		            System.out.println("0.Exit");
		            System.out.print("Choice:");
		            choice = in.nextInt();
		            switch (choice) {
		                case 1:
		                    if (obj.is_Full() != true)//if not full
		                    {
		                        System.out.print("Enter element:");
		                        e = in.nextInt();
		                        obj.enque(e);
		                        System.out.print("Entered " + e + " on queue");
		                    } else
		                        System.out.print("Queue Full");
		                    break;
		                case 2:
		                    if (obj.is_Empty() != true)//if not empty
		                        System.out.print("Element deque:" + obj.Dequeue());
		                    else
		                        System.out.print("queue Empty");
		                    break;
		                
		                case 3:
		                    if (obj.is_Empty() != true)//if not empty
		                    {
		                        System.out.print("Element in queue are:");
		                        obj.print_queue();;
		                    } else
		                        System.out.print("queue Empty");
		                    break;
		                case 0:
		                    System.out.print("Exiting code");
		                    break;
		                default:
		                    System.out.print("Wrong option selected...");
		                    break;
		            }
		     }while(choice!=0);
		        
		        System.out.println();
		        
		        System.out.println("Enter size of window");
		        int ws=in.nextInt();
		        while(ws>size) {
		        	System.out.println("Window size cant be greater than queue size");
		        	ws=in.nextInt();
		    }
		        obj.window(ws);
		        
		}

	
}
