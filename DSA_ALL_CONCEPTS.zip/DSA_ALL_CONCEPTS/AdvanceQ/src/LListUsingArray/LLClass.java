package LListUsingArray;
import java.util.Scanner;
//implement linear linkedlist using array
class Node {
	int data;
	int next;
	Node(){
		data=0;
		next=-1;
	}
	
}
public class LLClass {
	
	Node list[];
	int current;
	void create_list(int size) {
		current=0;
		list=new Node[size];
		for(int i=0;i<list.length;i++) {
			list[i]=new Node();
		}
	}
	
	void insert(int e) {
		list[current].data=e;
		
		if(current!=0) {
			list[current-1].next=current;
		}
		current++;
	}
	void print() {
		int c=0;
		while(c!=-1) {
			System.out.println(list[i].data+" "+list[i].next);
			c=list[c].next;
		}
	}
	
	
	public static void main(String args[]) {
	     LLClass obj=new LLClass();
	     obj.create_list(5);
	     obj.insert(12);
	     obj.insert(13);
	     obj.insert(42);
	     obj.insert(32);
	     obj.insert(22);
	     obj.print();
	     
	}
}
