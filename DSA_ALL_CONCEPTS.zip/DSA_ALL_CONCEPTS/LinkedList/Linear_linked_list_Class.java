
package LinkedList;
public class Linear_linked_list_Class
{
    Node root;//container-ship
    void create_List()
    {
        root=null;//making root null at start
    }
    void insert_Left(int data)
    {
        Node n=new Node(data);
        if(root==null)
            root=n;
        else
        {
            n.next=root;//1
            root=n;//2
        }
        System.out.println(data+" inserted in list");
    }
    //-----------------------------------------------------------------------------------------------------------
    void insert_Right(int data)
    {
        Node n=new Node(data);
        if(root==null)
            root=n;
        else
        {
            Node t=root;//1
            while(t.next!=null)//2
                t=t.next;
            t.next=n;//3
        }
        System.out.println(data+" inserted in list");
    }
    void delete_Left()
    {
        if (root == null)
            System.out.println("Empty List:");
        else {
            Node t = root;//1
            root = root.next;//2
            System.out.println(t.data + " Deleted from list");//3
        }
    }
   
    void delete_Right()
    {
        if (root == null)
            System.out.println("Empty List:");
        else
        {
            Node t = root;//1
            Node t2=root;//1
            if(root.next==null)//single node
                root=null;
            else
            {
                while(t.next!=null)
                {
                    t2=t;//ref
                    t=t.next;//next
                }
                t2.next=null;//3
            }
            System.out.println(t.data + " Deleted from list");//4
        }
    }

    void print_list()
    {
        if (root == null)
            System.out.println("Empty List:");
        else
        {
            Node t=root;
            while(t!=null)
            {
                System.out.print("|"+t.data +"|->");
                t=t.next;
            }
        }
    }
    void search(int key)
    {
        if (root == null)
            System.out.println("Empty List:");
        else
        {
            Node t=root;//1
            while(t!=null)
            {
                if(key==t.data)
                    break;
                t=t.next;
            }
            if(t==null)
                System.out.println(key+" not found");
            else
                System.out.println(key+" found");
        }
    }

    void delete_element(int element)
    {
        if (root == null)
            System.out.println("Empty List:");
        else
        {
            Node t=root;//1
            Node t2=root;
            while(t!=null)
            {
                if(element==t.data)
                    break;
                t2=t;
                t=t.next;
            }
            if(t==null)
                System.out.println(element+" not found");
            else//found so now delete
            {
                System.out.println(element+" found");
                if(t==root)//case 1
                    root=root.next;
                else if(t.next==null)//case 2
                    t2.next=null;
                else//case 3
                    t2.next=t.next;
                System.out.println(t.data + " Deleted from list");//4
            }
        }
    }
    
}