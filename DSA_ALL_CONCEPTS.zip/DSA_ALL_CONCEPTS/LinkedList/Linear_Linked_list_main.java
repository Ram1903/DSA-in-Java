package LinkedList;
import java.util.Scanner;
public class Linear_Linked_list_main {
	public static void main(String args[]) {
	   Linear_linked_list_Class obj=new Linear_linked_list_Class();
	   Scanner sc=new Scanner(System.in);
	   obj.create_List();
	   int choice;
	   do{
           System.out.println("\n Menu");
           System.out.println("-----------");
           System.out.println("1.insert left");
           System.out.println("2.delete left");
           System.out.println("3.insert right");
           System.out.println("4.print list");
           System.out.println("5.search");
           System.out.println("6.delete element");
           System.out.println("7.delete right");
           System.out.println("0.Exit");
           System.out.print("Choice:");
           choice = sc.nextInt();
           switch (choice) {
           case 1:
        	   System.out.println("Enter element");
        	   int e=sc.nextInt();
        	   obj.insert_Left(e);
        	   break;
           
           case 2:
               obj.delete_Left();
               System.out.println("Deleted");
               break;
           
           case 3:
        	   System.out.println("Enter element");
        	   int f=sc.nextInt();
        	   obj.insert_Right(f);
        	   System.out.println(f+" Data inserted");
        	   break;
        	   
           case 4:
        	   obj.print_list();
        	   break;
        	   
           case 5:
        	   System.out.println("Enter element");
        	   int g=sc.nextInt();
        	   obj.search(g);
        	   break;
        	   
           case 6:
        	   System.out.println("Enter element");
        	   int d=sc.nextInt();
        	   obj.delete_element(d);
        	   break;
        	   
           case 7:
        	   int x=sc.nextInt();
        	   obj.delete_Right();
        	   break;
           
           default:
        	   System.out.println("Invalid input:");
           }
	
	   }while(choice!=0);
}
}