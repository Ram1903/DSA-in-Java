package Priority_Queue;

public class Priority_Queue_Class {

    int queue[],front,rear,MaxSize;
    int sum=0;

    void create_Queue(int size)
    {
        MaxSize=size;
        queue=new int[size];
        front=0;
        rear=-1;
    }
    void Enqueue(int e)
    //Entry on queue
    {
        rear++;
        queue[rear]=e;
        for(int i=front;i<rear;i++)
        {
            for(int j=front;j<rear;j++)
            {
                if(queue[j]>queue[j+1])
                {
                    int temp=queue[j];
                    queue[j]=queue[j+1];
                    queue[j+1]=temp;
                }
            }
        }
        //queue[++rear]=e;
    }
    boolean is_Full()
    {
        if(rear==MaxSize-1)
            return true;
        else
            return false;
        //return tos==Maxsize-1
    }
    int Dequeue()//removes and return
    //Deletion from queue
    {
        int temp=queue[front];
        front++;
        return temp;
    }
    boolean is_Empty()
    {
        if(front>rear)
            return true;
        else
            return false;
    }
    void print_Queue()
    {
        for(int i=front;i<=rear;i++)
            System.out.print(queue[i]+"--");
    }
    
	}
