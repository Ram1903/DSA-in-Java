package Priority_Queue;
import java.util.Scanner;
public class Priority_Queue_main_ASC {
	

    public static void main(String args[]) {
        Scanner in = new Scanner(System.in);
       // Queue_Class obj=new Queue_Class();
        //Circular_Queue_Class obj=new Circular_Queue_Class();
        Priority_Queue_Class obj=new Priority_Queue_Class();
        System.out.println("Enter size of queue:");
        int choice, e;
        int size = in.nextInt();
        obj.create_Queue(size);
        //menu driven code for stack
        do{
            System.out.println("\nQueue Menu");
            System.out.println("-----------");
            System.out.println("1.Enqueue");
            System.out.println("2.Dequeue");
            System.out.println("3.Print");
            System.out.println("0.Exit");
            System.out.print("Choice:");
            choice = in.nextInt();
            switch (choice) {
                case 1:
                    if (obj.is_Full() != true)//if not full
                    {
                        System.out.print("Enter element:");
                        e = in.nextInt();
                        obj.Enqueue(e);
                        System.out.print("Entered " + e + " on queue");
                    } else
                        System.out.print("Queue Full");
                    break;
                case 2:
                    if (obj.is_Empty() != true)//if not empty
                        System.out.print("Element dequeued:" + obj.Dequeue());
                    else
                        System.out.print("Queue Empty");
                    break;
                case 3:
                    if (obj.is_Empty() != true)//if not empty
                    {
                        System.out.print("Element in queue are:");
                        obj.print_Queue();
                    } else
                        System.out.print("Stack Empty");
                    break;
                case 0:
                    System.out.print("Exiting code");
                    break;
                default:
                    System.out.print("Wrong option selected...");
                    break;
            }
        }while(choice!=0);
    }
}
