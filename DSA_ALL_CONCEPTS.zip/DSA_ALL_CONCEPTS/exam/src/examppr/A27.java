package examppr;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

/*1)create a customer class with following attributes
	custid
	custname
	address
	age
create one instance of it and store it in a file. (Serialization).
now open a file, read the object and read its contents . (Deserialization)*/
class customer implements Serializable{
	public int custid;
	public String name;
	public String Add;
	public int age;
}
public class A27 {
	public static void main(String args[]) {
		customer cs=new customer();
		cs.custid=10;
		cs.name="Ram";
		cs.Add="Dhamangaon";
		cs.age=22;
		
		String st="d://custDetail";
		try {
			FileOutputStream fos=new FileOutputStream(st);
			ObjectOutputStream oos=new ObjectOutputStream(fos);
			oos.writeObject(cs);
		}catch(Exception e) {
			System.out.println(e.getStackTrace());
		}
		
		try {
			FileInputStream fis=new FileInputStream(st);
			ObjectInputStream ois=new ObjectInputStream(fis);
			customer ob=(customer)ois.readObject();
			System.out.println(ob.custid+" "+ob.name+" "+ob.Add+" "+ob.age);
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
		}

}
