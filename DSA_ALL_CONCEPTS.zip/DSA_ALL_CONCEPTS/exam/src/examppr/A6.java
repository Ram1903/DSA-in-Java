package examppr;
/*
 5)	Show the example of multi-level inheritance with constructor invocation.
 */
class A6a{
	A6a(){
		System.out.println("A6a");
	}
}
class A1a extends A6a{
	A1a(){
		System.out.println("A1");
	}
}
class A2a extends A1a{
	A2a(){
		System.out.println("A2");
	}
}
public class A6 {
	public static void main(String args[]) {
		A2a ob=new A2a();
	}
}
