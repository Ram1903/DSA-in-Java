
package examppr;
/*
 10)	Define an interface “Vechicle” with “start()” function . Now derive  classes like “TwoWheeler”, “ThreeWheeler”,”FourWheeler” etc. from “Vehicle” and override “start()” function. Define a class “VDemo” in which  write  main()  function. In the main function create a reference to Vehicle  class referring to any of the sub class. Using this reference, call “start" method.
 */
interface vehicle20{
	void start();
}
class Twow implements vehicle20{
	public void start() {
		System.out.println("twow");
	}
}
class Threew implements vehicle20{
	public void start() {
		System.out.println("Threew");
	}
}
class fourw implements vehicle20{
	public void start() {
		System.out.println("Four");
	}
}

public class A20 {
	public static void main(String args[]) {
		vehicle20 obj=new fourw();
		obj.start();
	}
}
