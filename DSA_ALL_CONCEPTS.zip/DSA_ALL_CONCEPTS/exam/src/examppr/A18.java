package examppr;
/*
7) Define class "Parent1" with some data.
Define interface "Parent2" with some methods.
Derive a class "Child" from "Parent1" and "Parent2", instantiate it and call the members.
 */
class bap1{
	public int a=8;
}
interface bap2{
	void disp();
	
}
class betac extends bap1 implements bap2{

	@Override
	public void disp() {
		// TODO Auto-generated method stub
		System.out.println("batac");
	}
}
public class A18 {
	public static void main(String args[]) {
		betac bc=new betac();
		bc.disp();
		System.out.println(bc.a);
		
	}
}
