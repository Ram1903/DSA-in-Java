package examppr;

import java.util.LinkedList;
import java.util.List;

/*3) create LinkedList with the values 10,20,30 and 40.
display it.
now insert 500 in the beginning.
	insert 400 at 2nd position.
	add 1000 at the end.
display the list again.*/
public class A36 {
	public static void main(String[] args) {
		List<Integer> ll=new LinkedList<>();
		ll.add(10);
		ll.add(20);
		ll.add(30);
		ll.add(40);
		
		ll.addFirst(500);
		ll.add(2,400);
		ll.addLast(100);
		
		System.out.println(ll);
	}
}
