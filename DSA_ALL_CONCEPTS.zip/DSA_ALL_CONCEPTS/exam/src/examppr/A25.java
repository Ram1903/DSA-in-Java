package examppr;
/*
 4) on the developer side create following checked exception:
	InvalidLengthException
create necessary jar file and documentation.

on client side

public class Authenticator
	with
a parameterized constructor which takes String as a password.
this class also will have "done()" method with "successful authentication" message.
Parameterized constructor should check the length of the password passed if it is less than 5 or more that 9 , it should raise "InvalidLengthException" 
	[ constructor shouldn't handle the exception]

create a class "Demo" with main
	inside main function create the object of "Authenticator" class and invoke "done()" method.
 */
class InvalidLengthException extends Exception{
	public InvalidLengthException(String msg) {
		super(msg);
	}
}
class Authenticator{
	public String pwd;
	Authenticator(String pwd) throws InvalidLengthException{
		this.pwd=pwd;
		int l=pwd.length();
		try{if(l<5 || l>9) {
			throw new InvalidLengthException(pwd+ "Length between 5 to 9");
		}else{
			done();
		}}catch(InvalidLengthException e) {
			e.printStackTrace();
		}
	}
	void done() {
		System.out.println("Done");
	}
}
public class A25 {
 public static void main(String args[]) {
	 String k="jndialsijdssand";
	 try {
		Authenticator on=new Authenticator(k);
	} catch (InvalidLengthException e) {
		e.printStackTrace();
	}
 }
}
