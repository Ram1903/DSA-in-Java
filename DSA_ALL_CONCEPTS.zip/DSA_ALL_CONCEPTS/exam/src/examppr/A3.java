package examppr;
/*
 
2)	Create a class with static and non-static member variables. Define static and non-static member functions. Create instance of this class and call both static and non-static member functions.

 */
class stn{
	int a=10;
	static int b=20;
	static void draw() {
		
		System.out.println("Static");
	}
	void draw2() {
		//stn.draw();
		System.out.println("non static");
	}
}
public class A3 {
	public static void main(String args[]) {
		stn on=new stn();
		on.draw2();
		System.out.println(stn.b+" "+on.a);
		stn.draw();
	}
}
