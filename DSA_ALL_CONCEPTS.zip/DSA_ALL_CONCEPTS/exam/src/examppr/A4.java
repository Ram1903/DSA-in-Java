package examppr;
/*
3)Define a class “Check” in which declare member variables using  different accessibility modifiers i.e.<default>, private ,public and protected.   Define a function “disp”  which should be public.  Define a class “CheckDemo” in 
which you will write “main()” function. Create an instance of  the class “Check” and  show how many  variables can
be accessed directly and how many indirectly.
 */
class check{
	public int a=10;
	private int b=20;
	protected int c=30;
	int d=40;
	public void disp(){
		System.out.println(c);
	}
}
public class A4 {
	public static void main(String args[]) {
		check oba=new check();
		System.out.println(oba.d+" "+oba.a+" "+" "+oba.c);
		oba.disp();
	}
}
