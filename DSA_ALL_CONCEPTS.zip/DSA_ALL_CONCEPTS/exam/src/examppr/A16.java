package examppr;
/*
5) create abstract class Shape. declare "draw()" function as abstract. From this class define "Triangle","Polygon" and "Circle" .
create an array of Shape having 3 elements.
store child objects into this array . and call
their draw function.
*/
abstract class shape0{
	abstract void draw();
}
class Triangle0 extends shape0{
	void draw() {
		System.out.println("Triangle");
	}
}
class polygon0 extends shape0{
	void draw() {
		System.out.println("Polygon");
	}
}
class circle0 extends shape0{
	void draw() {
		System.out.println("circle");
	}
}
public class A16 {
	public static void main(String args[]) {
		shape0 arr[]=new shape0[3];
		arr[0]=new Triangle0();
		arr[1]=new polygon0();
		arr[2]=new circle0();
		for(int i=0;i<3;i++) {
			arr[i].draw();
		}
	}
}
