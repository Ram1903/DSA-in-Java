package examppr;
/*
 
3) define a functional interface "MyInterface" with an abstract method "void fun()"

define a class Demo with two functions "static void perform" and main.

from main function pass lambda expression, collect it in "perform" method and invoke "fun()" function.

 */
interface MyInterfaceh{
	void fun();
	default void mih() {
		System.out.println("mih");
	}
	static void mih2() {
		System.out.println("mih2");
	}
}
public class A33 {
	public static void main(String[] args) {
		MyInterfaceh ref=()->{System.out.println("Hello");};
		ref.mih();
		MyInterfaceh.mih2();
	}
}
