package examppr;
//2) create a class "Vehicle", define a method "public void start()" in it. From this class derive a class FourWheeler. How will u override "start()" method of parent class ?

class vehicle13{
	public void start() {
		System.out.println("vehicle13");
	}
}
class fourwheeler extends vehicle13{
	public void start() {
		super.start();
		System.out.println("fourwheeler");
	}
}
public class A13 {
	public static void main(String args[]) {
		vehicle13 on=new fourwheeler();
		on.start();
	}
}
