package examppr;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import java.util.Iterator;

/*
7) create a HashMap.
store  prn no. and students name of 10 students inside the HashMap.
now write this HashMap inside the file and read also. After reading display it using iterator.
*/
public class A37 {
	public static void main(String[] args) {
		HashMap<Integer,String> hm=new HashMap<>();
		hm.put(1,"A");
		hm.put(2,"B");
		hm.put(3,"c");
		hm.put(4,"d");
		
		try(ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream("d://A37n.txt"))){
			oos.writeObject(hm);
		}catch(Exception e) {
			e.printStackTrace();
			}
		HashMap<Integer,String> hmn=null;
		try(ObjectInputStream ois=new ObjectInputStream(new FileInputStream("d://A37n.txt"))){
			hmn=(HashMap<Integer, String>) ois.readObject();
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		System.out.println(hmn);
		try {
		Iterator<Integer> itr=hmn.keySet().iterator();
		
		while(itr.hasNext()) {
			Integer key=itr.next();
			System.out.println(key+" "+itr.get(key));
			}
		}catch(Exception e) {
			e.printStackTrace();			
		}
	}
}
