package examppr;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

class myc implements Serializable{
	public int id;
	public String name;
	myc(String name,int id) {
		this.name=name;
		this.id=id;
	}
	String getName(){
		return name;
	}
	int getid() {
		return id;
	}
	public String toString() {
		return name +" "+id;
		
	}
}
public class A29 {
	public static void main(String args[]) {
		List<myc> list=new ArrayList<>();
		list.add(new myc("hello",1));
		list.add(new myc("hello1",2));
		list.add(new myc("hello2",3));
		
		
		try(ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream("d://A20.txt"))) {
			oos.writeObject(list);
		}catch(Exception e) {
			e.printStackTrace();
		}
		List<myc> listn=null;
		try(ObjectInputStream ois=new ObjectInputStream(new FileInputStream("d://A20.txt"))){
			listn=(List<myc>)ois.readObject();
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		if (listn != null) {
            listn.forEach(System.out::println);
        }
	}
}
