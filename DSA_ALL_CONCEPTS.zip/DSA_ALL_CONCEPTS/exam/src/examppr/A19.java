package examppr;
/*
8) Define a class "base1" with only parameterized constructor.
Derive a class "sub1" from "base1". This class should have following constructors
	a) Default
	b) one parameter
	c) two parameter
Now try to instantiate "sub1" , using any of the above mentioned constructors.
 */
class basea1{
	basea1(int a){
		System.out.println(a);
	}
}
class suba1 extends basea1{

	suba1() {
		super(1);
		System.out.println("default");
	}
	suba1(int b){
		super(10);
		System.out.println("One parameter");
	}
	suba1(int a,int b){
		super(10);
		System.out.println("two parameter");
	}
	
}
public class A19 {
	public static void main(String args[]) {
		suba1 s=new suba1();
		suba1 f=new suba1(3);
		suba1 d=new suba1(4,5);
		
	}
}
