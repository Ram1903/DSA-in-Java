package examppr;
/*
 
3) define "MyException" as a checked exception.

define a class "Demo" with 
	public void show1(), public void show2() , public void show3() and main functions.

inside "show3()" accept a number and if it is greater than 10 raise "MyException" else display the number.
	[ this method shouldn't handle the exception]

main() function should call "show1()" , 
show1() function should call "show2()",
show2() function should call "show3()"

show2() should not handle the exception but show1() should handle.
 */

class MyException extends Exception{
	public MyException(String msg) {
		super(msg);
	}
}
public class A24 {
	public int a;
  public void show1(int a) throws MyException{
	  this.a=a;
	 if(a>10) {
		 throw new MyException(a+ " is greater than 10");
	 }else {
		 System.out.println("Accepted");
	 }
  }
public void show2(int a) throws MyException {
	  show1(a);
  }
public void show3(int a) throws MyException {
	  show2(a);
}
public static void main(String args[]) {
	A24 ob=new A24();
	try {
		ob.show3(8);
	} catch (MyException e) {
		e.printStackTrace();
	}
	try {
		ob.show3(88);
	} catch (MyException e) {
		e.printStackTrace();
	}
}
}
