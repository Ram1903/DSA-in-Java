package examppr;
/*
 
4) Create a class "Top1" with "disp1()" method.
From this class Derive "Bottom1", "Bottom2" and "Bottom3" classes ,override the "disp1()".
Now show how will u achieve dynamic polymorphism.
 */

class Top{
	void disp1() {
		System.out.println("top");
	}
}
class bottom1 extends Top{
	void disp1() {
		System.out.println("bottom");
	}
}
class bottom2 extends Top{
	void disp1() {
		System.out.println("bottom2");
	}
}
class bottom3 extends Top{
	void disp1() {
		System.out.println("bottom3");
	}
}
public class A15 {
	public static void main(String args[]) {
		Top top;
		Top a=new bottom1();
		Top b=new bottom2();
		Top c=new bottom3();
		
		a.disp1();
		b.disp1();
		c.disp1();
	}
}
