package examppr;
/*
5) on the developer side 
create checked exception "ResourceNotAllocatedException"

create a class:

public class MyResource implements AutoCloseable
{
	public MyResource(int capacity) throws ResourceNotAllocatedException
	{
		if(capacity>100)
		{
			throw new ResourceNotAllocatedException("not sufficient space");
		}
	}
    void disp()
    {
    	System.out.println("successful");
    }
	@Override
	public void close()  {
		System.out.println("resource is closed");
		
	}
}

create necessary jar file and documentation

on the client side
public class Demo with main function

	inside main function, create object of "MyResource" and invoke "disp()" method.
*/


class MyResource implements AutoCloseable
{
	public MyResource(int capacity) throws ResourceNotAllocatedException
	{
		if(capacity>100)
		{
			throw new ResourceNotAllocatedException("not sufficient space");
		}
	}
    void disp()
    {
    	System.out.println("successful");
    }
	@Override
	public void close()  {
		System.out.println("resource is closed");
		
	}
}
class ResourceNotAllocatedException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ResourceNotAllocatedException(String ss) {
		super(ss);
	}
}

public class A35 {
	public static void main(String args[]) {
		try {
			MyResource ob=new MyResource(15);
			ob.disp();
			ob.close();
		} catch (ResourceNotAllocatedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
