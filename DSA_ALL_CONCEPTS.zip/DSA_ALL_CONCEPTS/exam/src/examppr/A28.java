package examppr;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class A28 {
	public static void main(String args[]) {
		List<Integer> list=new ArrayList<>();
		list.add(10);
		list.add(20);
		list.add(30);
		
		try(ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream("d://combo.txt"))){
			oos.writeObject(list);
			}catch(Exception e) {
				System.out.println(e.getMessage());			
		}
		System.out.println("list "+ list);
		List<Integer> list1=null;
		try(ObjectInputStream ois=new ObjectInputStream(new FileInputStream("d://combo.txt"))){
			list1=(List<Integer>)ois.readObject();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("list1 "+list1);
		
		
		ListIterator<Integer> itr=list1.listIterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		
		while(itr.hasPrevious()) {
			System.out.println(itr.previous());
		}
	}
}
