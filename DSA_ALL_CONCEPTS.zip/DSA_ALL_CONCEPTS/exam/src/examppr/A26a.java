package examppr;
/*on the client side
public class Demo with main function

	inside main function, create object of "MyResource" and invoke "disp()" method.

 */
public class A26a {
	public static void main(String args[]) {
		A26 ob;
		try {
			ob = new A26(20);
		} catch (ResourceNotAllocatedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
