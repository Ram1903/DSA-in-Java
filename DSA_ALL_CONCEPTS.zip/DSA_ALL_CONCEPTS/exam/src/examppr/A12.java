package examppr;
//1) Create a multi-level inheritance , instantiate the child class and observe constructor invocation.Also show, if needed how will u invoke parent class constructor from child class ?
class ml{
	ml(){
		System.out.println("ml");
	}
}
class on extends ml{
	on(){
		System.out.println("on");
	}
}
class of extends on{
	of(){
		System.out.println("of");
	}
}
public class A12 {
	public static void main(String args[]) {
		of o=new of();
		
	}
}
