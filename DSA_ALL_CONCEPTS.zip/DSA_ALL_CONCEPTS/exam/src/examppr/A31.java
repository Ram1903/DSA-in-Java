package examppr;

class divThree {
	divThree(int num) throws NumberNotDivisibleByThree
	{
		if(num%3!=0) {
			throw new NumberNotDivisibleByThree(num+" Number not Divisible by 3");
		}else {
			System.out.println("Divisible by 3");
		}
	}
}
class NumberNotDivisibleByThree extends Exception{
	public NumberNotDivisibleByThree(String num) {
	super(num);
}}
public class A31 {
	public static void main(String[] args) {
		try {
			divThree ob=new divThree(9);
		} catch (NumberNotDivisibleByThree e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
