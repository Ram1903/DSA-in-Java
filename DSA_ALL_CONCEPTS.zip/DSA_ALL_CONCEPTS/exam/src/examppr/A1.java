package examppr;

/*
 Abstract Class, Checked Exception, and Constructor Chaining
Define an abstract class Shape with an abstract method draw().
Derive three classes Circle, Rectangle, and Triangle from Shape and override the draw() method.

Now, create a custom checked exception InvalidShapeException that is raised when a shape has invalid dimensions (e.g., radius <= 0 for Circle, or negative sides for Rectangle and Triangle).

In the ShapeDemo class, prompt the user for the dimensions of the shapes, instantiate objects of each shape, and handle the exception if invalid dimensions are provided. Use constructor chaining to pass these dimensions.

Try it.
 */
abstract class shape{
	abstract void draw();
}
class circle extends shape{
	void draw() {
		System.out.println("circle");	
	}
	circle(int r) throws InvalidShapeException{
		if(r<=0)
		  throw new InvalidShapeException("invalid circle "+r);
	}
}
class Rectangle extends shape{
	void draw() {
		System.out.println("Rectangle");
	}
	Rectangle(int a,int b) throws InvalidShapeException {
		if(a<=0 || b<=0) {
			throw new InvalidShapeException("invalid Rectangle "+a+" "+b);
		}
	}
}
class Triangle extends shape{
	void draw() {
		System.out.println(" Triangle");
		
	}
	Triangle(int a,int b,int c) throws InvalidShapeException{
		if(a<=0 || b<=0 || c<=0) {
			throw new InvalidShapeException("invalid Triangle "+a+b+c);
		}
	}
}
class InvalidShapeException extends Exception{
	public InvalidShapeException(String  message) {
		super(message);
}
	
}
public class A1 {
	public static void main(String args[]) {
		try {
			shape c=new circle(6);
			c.draw();
		}catch(InvalidShapeException e) {
			e.printStackTrace();
		}
		try {
			shape c=new circle(-2);
			c.draw();
		}catch(InvalidShapeException e) {
			e.printStackTrace();
		}
		try {
			shape c=new circle(0);
			c.draw();
		}catch(InvalidShapeException e) {
			e.printStackTrace();
		}
		
	}
}
