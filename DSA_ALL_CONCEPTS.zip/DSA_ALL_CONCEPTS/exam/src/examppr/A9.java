package examppr;
/*
 8)	  Define a parent class with one function. Define child class with the function having same name as of parent class function, but having different argument.
Create an instance of child class and call the functions. Make sure u have followed the concept of “function overloading “ in inheritance.
 */
class bap{
	void funb(int a) {
		System.out.println(a);
	}
}
class beta extends bap{
	void funb(String b) {
		System.out.println(b);
	}
}
public class A9 {
  public static void main(String args[]) {
	  beta bet=new beta();
	  bet.funb(8);
	  bet.funb("hello");
  }
}
