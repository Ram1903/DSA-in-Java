package examppr;
/*
 6)	Show the example of hierarchical inheritance with constructor invocation.
 */
class hf{
	hf(){
		System.out.println("hf");
	}
}
class j extends hf{
	j(){
		System.out.println("j");
	}
}
class k extends hf{
	k(){
		System.out.println("k");
	}
}
public class A7 {
	public static void main(String args[]) {
		j o=new j();
		k k=new k();
	}
}
