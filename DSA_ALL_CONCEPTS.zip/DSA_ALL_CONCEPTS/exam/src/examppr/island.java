package examppr;

public class island {
	
	public static void main(String args[]) {
		int arr[][]= {{1,0,1,0},
				     {1,1,1,0},
		             {0,0,0,1},
		             {1,1,0,0}};
		int count =0;
		
		for(int i=0;i<4;i++) {
			for(int j=0;j<4;j++) {
				
				if(arr[i][j]==1) {
					count++;
					while(i<3) {
					if(arr[++i][j]!=1 && arr[i][++j]!=1) {
						continue;
					}else {
						while(arr[i][j]!=1 && arr[i][j]!=1){
							i++;
							j++;
						}
					}
				}
				}
			}
		}
		System.out.println(count);
	}
}
