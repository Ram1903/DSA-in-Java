package examppr;
class Animal{
	void makeSound() {
		
	}

	public void attack() {
		// TODO Auto-generated method stub
		
	}
}
class Dog extends Animal {
	void makeSound() {
		System.out.println("dog");
	}
}
class tiger extends Animal{
	void makeSound() {
		System.out.println("tiger");
	}
	public void attack() {
		System.out.println("Attacking");
	}
}
class cat extends Animal{
	void makeSound() {
		System.out.println("cat");
	}
}
public class A21 {
	public static void perform(Animal ref) {
		if(ref instanceof tiger) {
			tiger temp=(tiger)ref;
		    temp.attack();
		}
		ref.makeSound();
		
	}
	public static void main(String args[]) {
		perform(new Dog());
		perform(new cat());
		perform(new tiger());
	}
}
