package examppr;
/*
 7)	Define a parent and a child class . Now explain function overriding with Example.
 */
class baapu{
	void over() {
		System.out.println("Over ib baapu");
	}
	void newd() {
		System.out.println("newd");
	}
}
class bacca extends baapu{
	void over() {
		super.over();
		System.out.println("over in baccha");
	}
}
public class A8 {
   public static void main(String args[]) {
	   bacca b=new bacca();
	   b.over();
	   b.newd();
	   baapu bp=new bacca();
	   bp.over();
	   bp.newd();
	   
   }
}
