package examppr;
/*
 1)	Define 2 classes “First” and “Second” with member variables , member functions and constructors of  your choice. Now define a class “Two” in which define main function . In main function create various instances of First and Second  and call their individual member functions.
 */
class First{
	First(){
		System.out.println("first in first");
	}
	void draw() {
		System.out.println("draw in first");
	}
}
class Second{
	Second() {
		super();
		System.out.println("Second in second");
	}
	void draw() {
		System.out.println("draw in second");
	}
}
public class A2 {
	public static void main(String args[]) {
		First o=new First();
		o.draw();
		Second ob=new Second();
		ob.draw();
		
	}
}
