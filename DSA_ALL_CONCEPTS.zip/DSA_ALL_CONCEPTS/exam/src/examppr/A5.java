package examppr;
/*4)	Show the example of single level inheritance with constructor invocation.*/
class base{
	base(){
		System.out.println("base");
	}
	void show() {
		System.out.println("show in base");
	}
}
class sub extends base{
	sub() {
		System.out.println("sub");
	}
	void show() {
		super.show();
		System.out.println("show in sub");
	}
}
public class A5 {
	public static void main(String agrs[]) {
		sub ob=new sub();
		ob.show();
	}
}
