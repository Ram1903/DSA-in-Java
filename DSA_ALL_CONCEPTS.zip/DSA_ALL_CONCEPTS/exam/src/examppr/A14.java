package examppr;
//3) Go for Hierarchical inheritance, create instances of child class and observe constructor invocation.
class har{
	har() {
		System.out.println("har");
	}
}
class ch extends har{
	ch() {
		System.out.println("ch");
	}
}
class ch2 extends har{
	ch2() {
		System.out.println("ch2");
	}
}
public class A14 {
	public static void main(String args[]) {
		ch2 on=new ch2();
		ch of=new ch();
	}
}
