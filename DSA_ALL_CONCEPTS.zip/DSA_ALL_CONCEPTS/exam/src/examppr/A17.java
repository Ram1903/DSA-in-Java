package examppr;
/*
6) Define interface "A" with "disp1()" method.
Derive from "A", interface "B" with "disp2" method.
Derive class "C" , from "B".
Instantiate class "C" and call its members as well as derived from parent interfaces.
*/

interface Aa17{
	void disp1();
}
interface Bb17 extends Aa17{
	void disp2();
}
class Cc17 implements Bb17{
	public void disp2() {
		System.out.println(3);
	}
	public void disp1() {
		System.out.println(4);
	}
}
public class A17 {
	public static void main(String args[]) {
		Cc17 c=new Cc17();
		c.disp2();
		c.disp1();
	}
}
