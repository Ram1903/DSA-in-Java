package examppr;

public class paths {
	public static void main(String args[]) {
		
	}
}
