package examppr;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.concurrent.CopyOnWriteArrayList;

public class Q1{
	public static void main(String args[]) {
		List<Integer> list=new CopyOnWriteArrayList<>();
		list.add(10);
		list.add(20);
		list.add(30);
		list.add(40);
		Iterator<Integer> i=list.iterator();
		List<Integer> newl=new ArrayList<>();
	
		while(i.hasNext()) {
			int k=i.next();
			if(k==30) {
				newl.add(100);
				newl.add(200);
			}
			
		}
		list.addAll(newl);
		System.out.println(list);
	}
}













