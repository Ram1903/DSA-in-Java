package examppr;
import java.util.*;
public class rotate {
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter array elements");
		int arr[][]=new int[3][3]; 
		int cpy[][]=new int[3][3];
		for(int i=0;i<3;i++) {
			for(int j=0;j<3;j++) {
				arr[i][j]=sc.nextInt();
			}
		}
		int k=2;
		for(int i=0;i<3;i++) {
			for(int j=0;j<3;j++) {
				cpy[j][i]=arr[k][j];
			}
			k--;
		}
		for(int i=0;i<3;i++) {
			for(int j=0;j<3;j++) {
				System.out.print(cpy[i][j]+" ");
			}
			System.out.println();
			}
	}
}
