package examppr;
/*
9)	Define a class “Shape” with “draw()” function . Now derive  classes like “Circle”, “Polygon”,”Rectangle” etc. from “Shape” and override “draw()” function. Define a class “ShapeDemo” in which  write  main()  function. In the main function create a reference to Shape class referring to any of the sub class. Using this reference, call “draw()” and check the result.
 */
class shape10{
	void draw() {
		
	}
}
class circle1 extends shape10{
	void draw() {
		System.out.println("circle");
	}
}
class polygon extends shape10{
	void draw() {
		System.out.println("polygon");
	}
}
class rectanglee extends shape10{
	void draw() {
		System.out.println("rectangle");
	}
}
public class A100 {
    public static void main(String args[]) {
    	shape10 ref=new rectanglee();
    	ref.draw();
    	
    }
}
