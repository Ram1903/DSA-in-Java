package examppr;
/*1) define a functional interface "First" with an abstract method "void disp1()" , default method "void disp2()" and a static method "void disp3()"

inside main function using lambda expression invoke "disp1()" and "disp2()" methods.
also invoke "disp3()" method inside main.
*/
interface Firstn{
	int disp1(int n);
	default void disp2() {
		System.out.println("disp2 in First");
	}
	static void disp3() {
		System.out.println("disp3 in First");
	}
}
public class A30 {
	public static void main(String args[]) {
		Firstn ref=(int n)->{return n;};
		ref.disp1(10);
		ref.disp2();
		
	}
}
