package examppr;
//10)	Define an interface “Vechicle” with “start()” function . Now derive  classes like “TwoWheeler”, “ThreeWheeler”,”FourWheeler” etc. from “Vehicle” and override “start()” function. Define a class “VDemo” in which  write  main()  function. In the main function create a reference to Vehicle  class referring to any of the sub class. Using this reference, call “start" method.

interface vehicle{
	void start();
}
class twowheeler implements vehicle{
	public void start() {
		System.out.println("twowheeler");
	}
}
class threewheel implements vehicle{
	public void start() {
		System.out.println("threewheel");
	}
}
class fourwheel implements vehicle{
	public void start() {
		System.out.println("fourwheel");
	}
}
public class A11 {
	public static void main(String args[]) {
		vehicle ve=new fourwheel();
		ve.start();
	}
}
