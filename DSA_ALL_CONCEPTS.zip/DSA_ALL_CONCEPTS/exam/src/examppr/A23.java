package examppr;
/*
 2) on the developer side create an exception:
	NumberNotDivisibleBySevenException
	as a checked exception

create necessary jar and documentation.

on client side
	public class MyMath class with 
		public void disp(int num)
this disp() method will check if the number passed is not divisible by 7 , it will raise "NumberNotDivisibleBySevenException" or else it will simply display the number passed.
	[ this method shouldn't handle the exception]

	public class Demo
		main function 
		invoke "disp()" of "MyMath" class.
 */
class NumberNotDivisibleBySevenException extends Exception{
	public NumberNotDivisibleBySevenException (String s) {
		super(s);
	}
}
class performnew {
	public void disp(int num) throws NumberNotDivisibleBySevenException{
		if(num%7!=0) {
			throw new NumberNotDivisibleBySevenException(num+" Not divisible by 7");
		}else {
			System.out.println(num+" divisible by 7");
		}
	}
}
public class A23{
	public static void main(String[] args) {
		performnew ob=new performnew();
//		try {
//			ob.disp(77);
//		} catch (NumberNotDivisibleBySevenException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		try {
			ob.disp(79);
		} catch (NumberNotDivisibleBySevenException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
