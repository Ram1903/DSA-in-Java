package examppr;
/*
2) define a functional interface "Second" with an abstract method "void disp4()".

define a class Demo with main function.
inside main function create two implementations of "Second" using lambda expression and display their names.
*/

interface Secondh{
	void disp();
	default void h() {
		System.out.println("h in second");
	}
	static void h2() {
		System.out.println("h2 in second");
	}
}
public class A32 {
	public static void main(String[] args) {
		Secondh one=()->{System.out.println("Hello");};
		one.h();
		Secondh.h2();
	}
}
