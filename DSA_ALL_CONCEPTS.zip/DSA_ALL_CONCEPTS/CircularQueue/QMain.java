package CircularQueue;

import java.util.Scanner;

public class QMain {
	public static void main(String args[]) {
		 Scanner sc=new Scanner(System.in);
		   QClass obj=new QClass();
		   obj.create_Queue();
		   int choice;
		   do{
	           System.out.println("\n Menu");
	           System.out.println("-----------");
	           System.out.println("1.insert left");
	           
	           System.out.println("2.delete left");
	           System.out.println("3.insert right");
	          
	           System.out.println("4.print ");
	           System.out.println("5.delete right");
	           System.out.println("0.Exit");
	           System.out.print("Choice:");
	           choice = sc.nextInt();
	           switch (choice) {
	           case 1:
	        	   System.out.println("Enter element");
	        	   int e=sc.nextInt();
	        	   obj.insert_left(e);
	        	   break;
	           
	           case 2:
	               obj.delete_Left();
	               System.out.println("Deleted");
	               break;
	           
	           case 3:
	        	   System.out.println("Enter element");
	        	   int f=sc.nextInt();
	        	   obj.insert_right(f);
	        	   System.out.println(f+" Data inserted");
	        	   break;
	        	   
	           case 4:
	        	   obj.print_list();
	        	   break;
	        	   
	           case 5:
	        	   obj.delete_Right();
	        	   break;
	           
	           default:
	        	   System.out.println("Invalid input:");
	           }
		
		   }while(choice!=0);
	}
}
