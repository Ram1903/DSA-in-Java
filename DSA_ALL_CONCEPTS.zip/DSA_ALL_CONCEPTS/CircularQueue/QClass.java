package CircularQueue;
import java.util.*;

public class QClass {
	 Node front, root,last;//container-ship
 
	 Scanner sc=new Scanner(System.in);
	    void create_Queue() {
	        last=front = root = null;
	    }
	
	   void insert_left(int data) {
		   Node n=new Node(data);
		   if(root ==null) {
			   root=last=n;
			   last.next=root;
			   
		   }else {
			   n.next=root;
			   root=n;
			   last.next=n;
		   }
	   }
	   void insert_right(int data) {
		   Node n=new Node(data);
		   if(root ==null) {
			   root=last=n;
			   
		   }else {
			  last.next=n;
			  last=n;
			  n.next=root;
		   }
	   }
	    void delete_Left()
	    {
	        if (root == null)
	            System.out.println("Empty List:");
	        else {
	            Node t = root;//1
	            root = root.next;//2
	            System.out.println(t.data + " Deleted from list");//3
	        }
	    }
	   
	    void delete_Right()
	    {
	        if (root == null)
	            System.out.println("Empty List:");
	        else
	        {
	            Node t = root;//1
	            Node t2=root;//1
	            if(root.next==null)//single node
	                root=null;
	            else
	            {
	                while(t.next!=null)
	                {
	                    t2=t;//ref
	                    t=t.next;//next
	                }
	                t2.next=null;//3
	            }
	            System.out.println(t.data + " Deleted from list");//4
	        }
	    }

	    void print_list()
	    {
	        if (root == null)
	            System.out.println("Empty List:");
	        else
	        {
	            Node t=root;
	            do
	            {
	                System.out.print("|"+t.data +"|->");
	                t=t.next;
	            }while(t!=root);
	        }
	    }


}
