package ReverseString;

public class Reverse_Class {


		
	char stack[];int tos;int MaxSize;

	void create_Stack(int size)
	{
	MaxSize=size;
	stack=new char[MaxSize];
	tos=-1;
	}
	void push(char e)
	{
	tos++;
	stack[tos]=e;
	}
	//stack[++tos]=e; }
	boolean is_Full()
	{
	if(tos==MaxSize-1)
	return true;
	else
	return false;
	}
	//return tos==Maxsize-1 }

	char pop(){//removes and return {
	char temp=stack[tos];
	tos--;
	return temp;
	}
	char peek(){//only returns {
	return stack[tos];
	}
	boolean is_Empty()
	{
	if(tos==-1)
	return true;
	else
	return false;
	}
	//return tos==-1 }
	void print_Stack()
	{
	for(int i=tos;i>-1;i--)
	System.out.println(stack[i]);
	}

	

}
