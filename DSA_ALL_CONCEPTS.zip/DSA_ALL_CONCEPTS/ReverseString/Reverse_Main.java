package ReverseString;
import java.util.Scanner;
public class Reverse_Main {
	public static void main(String args[]) {
		Reverse_Class obj=new Reverse_Class();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter string to reverse: ");
		String line=sc.next();
		obj.create_Stack(line.length());
		
		
		
          for(int i=0;i<line.length();i++) {
			
			char c=line.charAt(i);
			obj.push(c);
			
          }
          
          String rev="";
          while(!obj.is_Empty()) {
        	  rev=rev+obj.pop();
          }
          
          System.out.println("Reversed String\n"+rev);
         
	}
}
