package PracticeRev;

public class prefix {
	public static int Precedence(char c)
	{
    	System.out.println("priority");
		if(c == '('||c==')') return 0;
		else if(c == '+' || c=='-') return 1;
		else if(c == '*' || c=='/' || c=='%') return 2;
		else if(c=='^') return 3;
		
		return -1;
    }
}
