package PracticeRev;
import java.util.Scanner;
public class CirclarQmain {
	public static void main(String args[]) {
		CircularQ obj=new CircularQ();
		Scanner sc=new Scanner(System.in);
		int ch;
		obj.create();
		do {
			System.out.println("1.insert left\n2.delete left\n3.print\n0.exit..");
		    ch=sc.nextInt();
		    
		    switch(ch) {
		    case 1:
		    	System.out.println("Enter data to be added");
		    	int e=sc.nextInt();
		    	obj.insert_left(e);;
		    	System.out.println("Inserted");break;
		    	
		    case 2:
		    	
		    	 obj.delete_Left();
		    	break;
		    	
		    case 3:
		    	obj.print();break;
		    	
		   case 0:
		    	System.out.println("Exiting...");
		    }
		}while(ch!=0);
	}
}
