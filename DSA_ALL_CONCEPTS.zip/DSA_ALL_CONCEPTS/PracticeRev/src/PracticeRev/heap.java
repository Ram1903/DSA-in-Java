package PracticeRev;

public class heap {
	static void sort(int a[]) {
		int i,j,current;
		for( i=a.length-1;i>0;i--) {
			for(j=0;j<=i;j++) {
				current=j;
				if(current>0 && current/2>=0) {
					if(a[current/2]<a[current]) {
						int temp=a[current];
						a[current]=a[current/2];
						a[current/2]=temp;
					}
					current=current/2;
				}
				
			}
			int temp=a[0];
			a[0]=a[i];
			a[i]=temp;
		}
	}
}
