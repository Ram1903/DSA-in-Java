package PracticeRev;

public class DoublyClass {
	Dnode root;
	void create() {
		root=null;
	}
	
	void insert_left(int data) {
		Dnode n=new Dnode(data);
		if(root==null) {
			root=n;
		}else {
			n.right=root;
			root.left=n;
			root=n;
		}
		System.out.println("data inserted");
	}
	void delete_Left() {
		Dnode t=root;
		if(root.right==null) {
			root=null;
		}else {
			root=root.right;
			root.left=null;
			
		}
		System.out.println("Data deleted");
	}
	
	void insert_right(int data) {
		Dnode n=new Dnode(data);
		if(root==null) {
			root=n;
		}else {
			Dnode t=root;
			while(t.right!=null) {
				t=t.right;
			}
			t.right=n;
			n.left=t;
		}
	}
	
	void delete_right() {
		if(root.right==null) {
			root=null;
		}else {
			Dnode t=root;
			Dnode t2=root;
			while(t2.right!=null) {
				t=t2;
				t2=t2.right;
			}
			t.right=null;
			t2.left=null;
		}
	}
	
	void print() {
		Dnode t=root;
		if(root.right==null) {
			System.out.println(root.data);
		}
		while(t.right!=null) {
			t=t.right;
		}
		while(t.left!=null) {
			System.out.println(t.data+" ");
			t=t.left;
		}
	}
}
