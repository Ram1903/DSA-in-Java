package PracticeRev;
import java.util.Scanner;
public class TMain {
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		TreeClass obj=new TreeClass();
		int ch;
		obj.Create();
		do {
			System.out.println("1.insert\n2.search\n3.count Leaf\n4.inorder\n5.preorder\n6.postorder\n0.exit..");
		    ch=sc.nextInt();
		    
		    switch(ch) {
		    case 1:
		    	System.out.println("Enter data to be added");
		    	int e=sc.nextInt();
		    	obj.insert(obj.root, new TNode(e));
		    	System.out.println("Inserted");break;
		    	
		    case 2:
		    	System.out.println("Enter data to be searched");
		    	int s=sc.nextInt();
		    	System.out.println( obj.search(obj.root, s));
		    	break;
		    	
		    case 3:
		    	System.out.println( obj.count_Leaf(obj.root));break;
		    	
		    case 4:
		    	obj.inorder(obj.root);break;
		    	
		    case 5:
		    	obj.preorder(obj.root);break;
		    case 6:
		    	obj.postorder(obj.root);break;
		    case 0:
		    	System.out.println("Exiting...");
		    }
		}while(ch!=0);
	}
}
