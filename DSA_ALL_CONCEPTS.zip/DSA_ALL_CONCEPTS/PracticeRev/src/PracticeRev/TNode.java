package PracticeRev;

public class TNode {
	int data;
	TNode left,right;
	TNode(int data){
		this.data=data;
		left=right=null;
		}

}
