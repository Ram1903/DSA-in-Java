package PracticeRev;

public class NodeClass {
	int data;
	NodeClass next;
	NodeClass(int data){
		this.data=data;
		this.next=null;
	}
}
