package PracticeRev;

public class Stack_Class {
	int stack[],tos,MaxSize;
	
	void create_Stack(int size) {
		MaxSize=size;
		stack=new int[MaxSize];
		tos=-1;
	}
	void push(int data) {
		tos++;
		stack[tos]=data;
	}
	boolean isFull() {
		if(tos==MaxSize-1) {
			return true;
		}else {
			return false;
		}
	}
	int pop() {
		int temp=stack[tos];
		tos--;
		return temp;
	}
	int peek() {
		return stack[tos];
	}
	boolean isEmpty() {
		if(tos==-1) {
			return true;
		}else {
			return false;
		}
	}
	void print() {
		for(int i=0;i<=tos;i++) {
			System.out.print(stack[i]+" ");
		}
	}
}
