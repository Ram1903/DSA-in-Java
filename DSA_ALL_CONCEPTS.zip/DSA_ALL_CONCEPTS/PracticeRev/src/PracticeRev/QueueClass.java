package PracticeRev;

public class QueueClass {
	int queue[],front,rear,MaxSize;
	void createQueue(int size) {
		MaxSize=size;
		queue=new int[MaxSize];
		front=0;
		rear=-1;
	}
	
	void enqueue(int data) {
		if(isFull()==false) {
			rear++;
			queue[rear]=data;
			
		}else {
			System.out.println("Queue is full");
		}
	}
	
	int dequeue() {
		int temp;
		if(isEmpty()!=true) {
			temp=queue[front];
			front++;
			return temp;
		}
		return MaxSize;
	}
	void print() {
			int i=front;
			while(i<=rear) {
			System.out.println(queue[i++]);
		}
	}

	private boolean isEmpty() {
		if(rear==-1) {
		return false;}else {
			return true;
		}
	}

	private boolean isFull() {
		if(rear==MaxSize) {
			return true;
		}else {
			return false;
		}
	}
}
