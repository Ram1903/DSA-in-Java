package PracticeRev;

import java.util.Scanner;

public class DynamicLinkedListMain {
	public static void main(String args[]) {
		DynamicLinkedListClass obj=new DynamicLinkedListClass();
		Scanner sc=new Scanner(System.in);
		
		obj.create_Stack();
		int ch;
		do {
			System.out.println("1.Push\n2.pop\n3.peek\n4.print\n0.Exit");
			ch=sc.nextInt();
			switch(ch) {
			case 1: 
				System.out.println("Enter integer to be push");
				int i=sc.nextInt();
				obj.push(i);
				System.out.println("Data added");
				break;
			case 2:
				
					obj.pop();
				    break;
				
			case 3:
				 obj.peek();
				break;
				
			case 4:
				obj.print();
				System.out.println();break;
			case 0:
				System.out.println("Exiting.....");
				
			}
		}while(ch!=0);
	}

}
