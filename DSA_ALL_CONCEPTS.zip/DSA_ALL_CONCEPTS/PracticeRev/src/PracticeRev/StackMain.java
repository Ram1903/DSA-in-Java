package PracticeRev;
import java.util.Scanner;
public class StackMain {
	public static void main(String args[]) {
		Stack_Class obj=new Stack_Class();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter size of stack");
		int s=sc.nextInt();
		obj.create_Stack(s);
		int ch;
		do {
			System.out.println("1.Push\n2.pop\n3.peek\n4.print\n0.Exit");
			ch=sc.nextInt();
			switch(ch) {
			case 1: 
				if(obj.isFull()!=true) {
				System.out.println("Enter integer to be push");
				int i=sc.nextInt();
				obj.push(i);
				System.out.println("Data added");
				}else {
					System.out.println("Stack is full");
				}break;
			case 2:
				if(obj.isEmpty()!=true) {
					System.out.println( obj.pop());
				}else {
					System.out.println("Stack is empty");
				}break;
				
			case 3:
				if(obj.isEmpty()!=true) {
				System.out.println( obj.peek());
				}else {
					System.out.println("Stack is empty");
				}break;
				
			case 4:
				obj.print();
				System.out.println();break;
			case 0:
				System.out.println("Exiting.....");
				
			}
		}while(ch!=0);
	}
}
