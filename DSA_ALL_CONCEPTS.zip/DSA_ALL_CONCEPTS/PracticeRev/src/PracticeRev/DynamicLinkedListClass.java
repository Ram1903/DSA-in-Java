package PracticeRev;

public class DynamicLinkedListClass {
	NodeClass tos;
	void create_Stack() {
		tos=null;
	}
	 void push(int data) {
		 NodeClass n=new NodeClass(data);
		 if(tos==null) {
			 tos=n;
		 }else {
			 n.next=tos;
			 tos=n;
		 }
		 System.out.println("Data pushed on stack");
	 }
	 
	 void peek() {
		 if(tos==null) {
			 System.out.println("Empty");
		 }else {
		 System.out.println( tos.data);
		 }
	 }
	 void pop() {
		 if(tos==null) {
			 System.out.println("Empty");
		 }else {
		 NodeClass n=tos;
		 tos=n.next;
		 System.out.println( n.data);
		 }
		 
	 }
	 void print() {
		 if (tos == null)
	            System.out.println("Empty Stack:");
	        else
	        {
	            NodeClass t=tos;
	            while(t!=null)
	            {
	                System.out.println(t.data);
	                System.out.println("-----");
	                t=t.next;
	            }
	        }
	 }
}
