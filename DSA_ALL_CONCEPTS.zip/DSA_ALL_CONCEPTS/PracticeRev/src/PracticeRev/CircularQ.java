package PracticeRev;

public class CircularQ {
	Node root,last;
	
	void create() {
		root=last=null;
	}
	
	void insert_left(int data) {
		Node n=new Node(data);
		if(root==null) {
			root=n;
			last=n;
			last.next=root;
		}else {
			n.next=root;
			root=n;
			last.next=root;
		}
	}
	
	void delete_Left() {
		if(root==null) {
			System.out.println("List is empty");
		}else {
			if(root==last) {
				root=last=null;
			}else {
				root=root.next;
				last.next=root;
			}
			System.out.println("Deleted");
		}
	}
	
	void print() {
		Node t=root;
		do {
			System.out.println(t.data+" ");
			t=t.next;
		}while(t!=root);
	}
	
	
}
