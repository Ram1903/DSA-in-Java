package PracticeRev;

public class TreeClass {
	TNode root;
	void Create() {
		root=null;
	}
	
	void insert(TNode r,TNode d) {
		if(root==null) {
			root=d;
		}else {
			if(d.data<r.data) {
				if(r.left==null) {
					r.left=d;
				}else {
					insert(r.left,d);
				}
			}else {
				if(r.right==null) {
					r.right=d;
				}else {
					insert(r.right,d);
				}
			}
		}
	}
	int search(TNode r,int k) {
		
			if(r.data==k) {
				return r.data;
			}
			if(r.data<k) {
				return search(r.right,k);
			}else {
				return search(r.left,k);
			}
		
	}
	
	int count_Leaf(TNode r) {
		if(r==null) {
			return 0;
		}
		if(r.left==null && r.right==null) {
			return 1;
		}
		return count_Leaf(r.left)+count_Leaf(r.right);
	}
	
	void inorder(TNode r) {
		if(r!=null) {
		inorder(r.left);
		System.out.println(r.data);
		inorder(r.right);
		}
	}
	
	void preorder(TNode r) {
		if(r!=null) {
		System.out.println(r.data);
		preorder(r.left);
		preorder(r.right);
		}
	}
	
	void postorder(TNode r) {
		if(r!=null) {
			postorder(r.left);
			postorder(r.right);
			System.out.println(r.data);
		}
	}
}
