package PracticeRev;

public class Dnode {
	int data;
	Dnode left;
	Dnode right;
	Dnode(int data){
		this.data=data;
		left=right=null;
	}
}
