package PracticeRev;
import java.util.Scanner;

public class PostfixMain {
    public static int precedence(char c) {
        if (c == '(' || c == ')') {
            return 0;
        } else if (c == '+' || c == '-') {
            return 1;
        } else if (c == '*' || c == '/' || c == '%') {
            return 2;
        } else if (c == '^') {
            return 3;
        }
        return -1;
    }

    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter length");
        String postfix = "";
        String w = sc.next();
        int l = w.length();
        Stack_Class obj = new Stack_Class();
        obj.create_Stack(l);

        for (int i = 0; i < l; i++) {
            char c = w.charAt(i);
            switch (c) {
                case '(':
                    obj.push(c);
                    break;
                case ')':
                    while (!obj.isEmpty() && (char) obj.peek() != '(') {
                        postfix += obj.pop();
                    }
                    obj.pop(); // pop the '('
                    break;
                case '^':
                case '+':
                case '-':
                case '*':
                case '/':
                case '%':
                    while (!obj.isEmpty() && precedence(c) <= precedence((char) obj.peek())) {
                        postfix += obj.pop();
                    }
                    obj.push(c);
                    break;
                default:
                    postfix += c;
                    break;
            }
        }

        while (!obj.isEmpty()) {
            postfix += obj.pop();
        }

        System.out.println("ans: " + postfix);
        sc.close();
    }
}
