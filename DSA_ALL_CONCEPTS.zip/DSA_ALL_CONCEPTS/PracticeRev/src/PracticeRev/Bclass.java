package PracticeRev;

public class Bclass {
	int v,visited[],g[][];
	void create(int s) {
		v=s;
		visited=new int[v];
		g=new int[v][v];
		 for(int i =0;i<v;i++)//source
	        {
	            for(int j=0;j<v;j++)//dest
	            {
	                System.out.println("Enter value for v"+i+" to v"+j+" (999 for infinity):");
	                g[i][j]=in.nextInt();

	            }
	        }
	}
	void printG() {
		
	}
	void resetVisited() {
		
	}
	public void dfs(int source) {
		visited[source]=1;
		
		for(int i=0;i<v;i++) {
			if(g[source][i]==1 && visited[i]!=1) {
				dfs(i);
			}
		}
	}
}
