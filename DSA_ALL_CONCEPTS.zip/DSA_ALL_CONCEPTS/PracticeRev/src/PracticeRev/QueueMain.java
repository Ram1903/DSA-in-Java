package PracticeRev;

import java.util.Scanner;

public class QueueMain {
	public static void main(String args[]) {
		QueueClass obj=new QueueClass();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter size of Queue");
		int s=sc.nextInt();
		obj.createQueue(s);
		int ch;
		do {
			System.out.println("1.Enqueue\n2.Dequeue\n3.print\n0.Exit");
			ch=sc.nextInt();
			switch(ch) {
			case 1: 
				
				System.out.println("Enter integer to be enqueue");
				int i=sc.nextInt();
				obj.enqueue(i);
				System.out.println("Data added");
				break;
			case 2:
				
					System.out.println( obj.dequeue());
				break;
				
			case 3:
				obj.print();;
				System.out.println();break;
			case 0:
				System.out.println("Exiting.....");
				
			}
		}while(ch!=0);
	}

}
