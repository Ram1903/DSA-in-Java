package PracticeRev;

public class DLQueue {
	DynamicLinkedListClass obj=new DynamicLinkedListClass();
	NodeClass front,rear;
	void create_q() {
		front=rear=null;
	}
	
	void enqueue(int data) {
		NodeClass n=new NodeClass(data);
		if(rear==null) {
			front=rear=n;
		}else {
			rear.next=n;
			rear=n;
		}
	}
	void dequeue() {
		if(rear==null) {
			System.out.println("Empty");
		}else {
		int temp=front.data;
		front=front.next;
		System.out.println(temp+" data removed");
		}
	}
	void print() {
		NodeClass t=front;
		while(t!=null) {
			System.out.print(t.data+" ");
			t=t.next;
		}
	}
}
